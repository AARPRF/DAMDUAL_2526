﻿using LibreriaAgenda;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace AgendaApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            try
            {
                pnlMenuLateral.SendToBack();
                txtBuscadorSuperior.SendToBack();
                flpContenedorContactos.BringToFront();
                this.Load += new EventHandler(Form1_Load);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error en el inicio del formulario: " + ex.Message);
            }
        }

        private void Form1_Load(object? sender, EventArgs e)
        {
            ActualizarLista();
        }

        public void ActualizarLista()
        {
            try
            {
                flpContenedorContactos.Controls.Clear();
                txtBuscar.Visible = true;

                string ruta = Path.Combine(Application.StartupPath, "agenda.json");

                if (File.Exists(ruta))
                {
                    string contenido = File.ReadAllText(ruta);
                    var lista = JsonConvert.DeserializeObject<List<Contacto>>(contenido) ?? new List<Contacto>();

                    foreach (Contacto con in lista.OrderBy(c => c.Nombre))
                    {
                        FilaContacto fila = new FilaContacto();
                        fila.Configurar(con);
                        fila.Height = 110;
                        fila.Width = flpContenedorContactos.Width - 40;
                        fila.Margin = new Padding(10, 5, 10, 5);
                        fila.BackColor = Color.White;
                        fila.Visible = true;
                        flpContenedorContactos.Controls.Add(fila);
                    }
                    flpContenedorContactos.PerformLayout();
                }
            }
            catch (JsonException ex)
            {
                MessageBox.Show("Error en el formato de la base de datos: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los contactos: " + ex.Message);
            }
        }

        private void btnCrearContacto_Click(object sender, EventArgs e)
        {
            try
            {
                flpContenedorContactos.Controls.Clear();
                FormCrearContacto ventana = new FormCrearContacto();
                ventana.TopLevel = false;
                ventana.FormBorderStyle = FormBorderStyle.None;
                ventana.Size = new Size(flpContenedorContactos.Width - 10, flpContenedorContactos.Height - 10);
                flpContenedorContactos.Controls.Add(ventana);
                ventana.Show();
                ventana.BringToFront();
                ventana.FormClosed += (s, args) => ActualizarLista();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al abrir el formulario de creación: " + ex.Message);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string filtro = txtBuscar.Text.ToLower().Trim();
                foreach (Control c in flpContenedorContactos.Controls)
                {
                    if (c is FilaContacto fila)
                    {
                        bool coincide = fila.lblNombreReal.Text.ToLower().Contains(filtro);
                        fila.Visible = (string.IsNullOrWhiteSpace(filtro) || filtro == "buscar contacto") || coincide;
                    }
                }
            }
            catch (Exception) { }
        }

        private void btn_Paint(object sender, PaintEventArgs e)
        {
            try
            {
                Button btn = (Button)sender;
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                Rectangle rect = new Rectangle(0, 0, btn.Width, btn.Height);
                int radius = 20;
                System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
                path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
                path.AddArc(rect.Right - radius, rect.Y, radius, radius, 270, 90);
                path.AddArc(rect.Right - radius, rect.Bottom - radius, radius, radius, 0, 90);
                path.AddArc(rect.X, rect.Bottom - radius, radius, radius, 90, 90);
                path.CloseFigure();
                btn.Region = new Region(path);
                using (SolidBrush brush = new SolidBrush(btn.BackColor))
                {
                    e.Graphics.FillPath(brush, path);
                }
                using (Pen pen = new Pen(Color.Black, 2))
                {
                    e.Graphics.DrawPath(pen, path);
                }
                TextRenderer.DrawText(e.Graphics, btn.Text, btn.Font, rect, btn.ForeColor,
                                      TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            }
            catch (Exception) { }
        }
    }
}