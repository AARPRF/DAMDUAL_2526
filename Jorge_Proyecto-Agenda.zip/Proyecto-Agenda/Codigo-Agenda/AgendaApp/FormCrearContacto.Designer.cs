﻿namespace AgendaApp
{
    partial class FormCrearContacto
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            txtNombre = new TextBox();
            txtApellidos = new TextBox();
            txtTelefono1 = new TextBox();
            txtEmpresa = new TextBox();
            txtEmail = new TextBox();
            dtpCumpleaños = new DateTimePicker();
            btnGuardar = new Button();
            btnMasTelefono = new Button();
            IconoUsuario = new PictureBox();
            imgBack = new PictureBox();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)IconoUsuario).BeginInit();
            ((System.ComponentModel.ISupportInitialize)imgBack).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(121, 78);
            txtNombre.Margin = new Padding(4, 5, 4, 5);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(155, 31);
            txtNombre.TabIndex = 6;
            txtNombre.Text = "Nombre";
            // 
            // txtApellidos
            // 
            txtApellidos.Location = new Point(121, 148);
            txtApellidos.Margin = new Padding(4, 5, 4, 5);
            txtApellidos.Name = "txtApellidos";
            txtApellidos.Size = new Size(155, 31);
            txtApellidos.TabIndex = 5;
            txtApellidos.Text = "Apellido";
            // 
            // txtTelefono1
            // 
            txtTelefono1.Location = new Point(121, 223);
            txtTelefono1.Margin = new Padding(4, 5, 4, 5);
            txtTelefono1.Name = "txtTelefono1";
            txtTelefono1.Size = new Size(155, 31);
            txtTelefono1.TabIndex = 4;
            txtTelefono1.Text = "Telefono";
            // 
            // txtEmpresa
            // 
            txtEmpresa.Location = new Point(121, 325);
            txtEmpresa.Margin = new Padding(4, 5, 4, 5);
            txtEmpresa.Name = "txtEmpresa";
            txtEmpresa.Size = new Size(155, 31);
            txtEmpresa.TabIndex = 3;
            txtEmpresa.Text = "Empresa";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(121, 427);
            txtEmail.Margin = new Padding(4, 5, 4, 5);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(155, 31);
            txtEmail.TabIndex = 2;
            txtEmail.Text = "Email";
            // 
            // dtpCumpleaños
            // 
            dtpCumpleaños.Location = new Point(121, 529);
            dtpCumpleaños.Margin = new Padding(4, 5, 4, 5);
            dtpCumpleaños.Name = "dtpCumpleaños";
            dtpCumpleaños.Size = new Size(311, 31);
            dtpCumpleaños.TabIndex = 1;
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(367, 14);
            btnGuardar.Margin = new Padding(4, 5, 4, 5);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(196, 67);
            btnGuardar.TabIndex = 0;
            btnGuardar.Text = "Guardar Contacto";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnMasTelefono
            // 
            btnMasTelefono.Location = new Point(299, 223);
            btnMasTelefono.Name = "btnMasTelefono";
            btnMasTelefono.Size = new Size(40, 31);
            btnMasTelefono.TabIndex = 7;
            btnMasTelefono.Text = "+";
            btnMasTelefono.UseVisualStyleBackColor = true;
            btnMasTelefono.Click += btnMasTelefono_Click;
            // 
            // IconoUsuario
            // 
            IconoUsuario.Image = Properties.Resources.contacts_product_50dp_000000_FILL0_wght400_GRAD0_opsz48;
            IconoUsuario.Location = new Point(12, 70);
            IconoUsuario.Name = "IconoUsuario";
            IconoUsuario.Size = new Size(78, 75);
            IconoUsuario.TabIndex = 8;
            IconoUsuario.TabStop = false;
            // 
            // imgBack
            // 
            imgBack.Image = Properties.Resources.arrow_back_50dp_000000_FILL0_wght400_GRAD0_opsz48;
            imgBack.Location = new Point(12, 12);
            imgBack.Name = "imgBack";
            imgBack.Size = new Size(69, 47);
            imgBack.TabIndex = 9;
            imgBack.TabStop = false;
            imgBack.Click += imgBack_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.phone_enabled_50dp_000000_FILL0_wght400_GRAD0_opsz48;
            pictureBox1.Location = new Point(12, 196);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(78, 75);
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.apartment_50dp_000000_FILL0_wght400_GRAD0_opsz48;
            pictureBox2.Location = new Point(12, 302);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(78, 75);
            pictureBox2.TabIndex = 11;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.stacked_email_50dp_000000_FILL0_wght400_GRAD0_opsz48;
            pictureBox3.Location = new Point(12, 407);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(78, 75);
            pictureBox3.TabIndex = 12;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = Properties.Resources.cake_50dp_000000_FILL0_wght400_GRAD0_opsz48;
            pictureBox4.Location = new Point(12, 510);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(78, 75);
            pictureBox4.TabIndex = 13;
            pictureBox4.TabStop = false;
            // 
            // FormCrearContacto
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(585, 652);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(imgBack);
            Controls.Add(IconoUsuario);
            Controls.Add(btnMasTelefono);
            Controls.Add(btnGuardar);
            Controls.Add(dtpCumpleaños);
            Controls.Add(txtEmail);
            Controls.Add(txtEmpresa);
            Controls.Add(txtTelefono1);
            Controls.Add(txtApellidos);
            Controls.Add(txtNombre);
            Margin = new Padding(4, 5, 4, 5);
            Name = "FormCrearContacto";
            Text = "Añadir Nuevo Contacto";
            ((System.ComponentModel.ISupportInitialize)IconoUsuario).EndInit();
            ((System.ComponentModel.ISupportInitialize)imgBack).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNombre;
        private TextBox txtApellidos;
        private TextBox txtTelefono1;
        private TextBox txtEmpresa;
        private TextBox txtEmail;
        private DateTimePicker dtpCumpleaños;
        private Button btnGuardar;
        private Button btnMasTelefono;
        private PictureBox IconoUsuario;
        private PictureBox imgBack;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
    }
}