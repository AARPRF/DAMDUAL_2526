﻿namespace AgendaApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            flpContenedorContactos = new FlowLayoutPanel();
            txtBuscadorSuperior = new Panel();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            txtBuscar = new TextBox();
            pnlMenuLateral = new Panel();
            btnCrearContacto = new Button();
            txtBuscadorSuperior.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            pnlMenuLateral.SuspendLayout();
            SuspendLayout();
            // 
            // flpContenedorContactos
            // 
            flpContenedorContactos.AutoScroll = true;
            flpContenedorContactos.BackColor = Color.LightGray;
            flpContenedorContactos.Dock = DockStyle.Fill;
            flpContenedorContactos.FlowDirection = FlowDirection.TopDown;
            flpContenedorContactos.Location = new Point(269, 115);
            flpContenedorContactos.Margin = new Padding(4, 5, 4, 5);
            flpContenedorContactos.Name = "flpContenedorContactos";
            flpContenedorContactos.Padding = new Padding(14, 17, 14, 0);
            flpContenedorContactos.Size = new Size(874, 635);
            flpContenedorContactos.TabIndex = 0;
            flpContenedorContactos.WrapContents = false;
            // 
            // txtBuscadorSuperior
            // 
            txtBuscadorSuperior.Controls.Add(pictureBox2);
            txtBuscadorSuperior.Controls.Add(pictureBox1);
            txtBuscadorSuperior.Controls.Add(txtBuscar);
            txtBuscadorSuperior.Dock = DockStyle.Top;
            txtBuscadorSuperior.Location = new Point(0, 0);
            txtBuscadorSuperior.Margin = new Padding(4, 5, 4, 5);
            txtBuscadorSuperior.Name = "txtBuscadorSuperior";
            txtBuscadorSuperior.Size = new Size(1143, 115);
            txtBuscadorSuperior.TabIndex = 2;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.White;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(169, 34);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(63, 31);
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.menu_50dp_000000_FILL0_wght400_GRAD0_opsz48;
            pictureBox1.Location = new Point(35, 25);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(53, 56);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // txtBuscar
            // 
            txtBuscar.BackColor = SystemColors.Window;
            txtBuscar.Location = new Point(225, 34);
            txtBuscar.Margin = new Padding(4, 5, 4, 5);
            txtBuscar.Name = "txtBuscar";
            txtBuscar.Size = new Size(437, 31);
            txtBuscar.TabIndex = 0;
            txtBuscar.Text = "                   BUSCAR CONTACTO";
            // 
            // pnlMenuLateral
            // 
            pnlMenuLateral.BackColor = Color.LightGray;
            pnlMenuLateral.Controls.Add(btnCrearContacto);
            pnlMenuLateral.Dock = DockStyle.Left;
            pnlMenuLateral.Location = new Point(0, 115);
            pnlMenuLateral.Margin = new Padding(4, 5, 4, 5);
            pnlMenuLateral.Name = "pnlMenuLateral";
            pnlMenuLateral.Size = new Size(269, 635);
            pnlMenuLateral.TabIndex = 3;
            // 
            // btnCrearContacto
            // 
            btnCrearContacto.BackColor = Color.Cyan;
            btnCrearContacto.FlatStyle = FlatStyle.Flat;
            btnCrearContacto.Location = new Point(13, 53);
            btnCrearContacto.Margin = new Padding(0);
            btnCrearContacto.Name = "btnCrearContacto";
            btnCrearContacto.Size = new Size(210, 38);
            btnCrearContacto.TabIndex = 0;
            btnCrearContacto.Text = "+ CREAR CONTACTO";
            btnCrearContacto.UseVisualStyleBackColor = false;
            btnCrearContacto.Click += btnCrearContacto_Click;
            btnCrearContacto.Paint += btn_Paint;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(1143, 750);
            Controls.Add(flpContenedorContactos);
            Controls.Add(pnlMenuLateral);
            Controls.Add(txtBuscadorSuperior);
            Margin = new Padding(4, 5, 4, 5);
            Name = "Form1";
            Text = "Form1";
            txtBuscadorSuperior.ResumeLayout(false);
            txtBuscadorSuperior.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            pnlMenuLateral.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private FlowLayoutPanel flpContenedorContactos;
        private Panel txtBuscadorSuperior;
        private TextBox txtBuscar;
        private Panel pnlMenuLateral;
        private Button btnCrearContacto;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
    }
}