using LibreriaAgenda;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace AgendaApp
{
    public partial class FormCrearContacto : Form
    {
        private List<TextBox> listaTxtTelefonos = new List<TextBox>();

        public FormCrearContacto()
        {
            InitializeComponent();

            try
            {
                listaTxtTelefonos.Add(txtTelefono1);

                ConfigurarPlaceholder(txtNombre, "Nombre");
                ConfigurarPlaceholder(txtApellidos, "Apellidos");
                ConfigurarPlaceholder(txtEmail, "Email");
                ConfigurarPlaceholder(txtEmpresa, "Empresa");
                ConfigurarPlaceholder(txtTelefono1, "Tel�fono");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al inicializar campos: " + ex.Message);
            }
        }

        private void btnMasTelefono_Click(object sender, EventArgs e)
        {
            try
            {
                TextBox nuevoTxt = new TextBox();
                nuevoTxt.Size = txtTelefono1.Size;
                int yOffset = (listaTxtTelefonos.Count * 35);
                nuevoTxt.Location = new Point(txtTelefono1.Left, txtTelefono1.Top + yOffset);

                this.Controls.Add(nuevoTxt);
                listaTxtTelefonos.Add(nuevoTxt);
                nuevoTxt.BringToFront();

                ConfigurarPlaceholder(nuevoTxt, "Tel�fono adicional");
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se pudo a�adir el campo de tel�fono: " + ex.Message);
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                Contacto nuevo = new Contacto();

                nuevo.Nombre = (txtNombre.Text == "Nombre") ? "" : txtNombre.Text;
                nuevo.Apellidos = (txtApellidos.Text == "Apellidos") ? "" : txtApellidos.Text;
                nuevo.Email = (txtEmail.Text == "Email") ? "" : txtEmail.Text;
                nuevo.Empresa = (txtEmpresa.Text == "Empresa") ? "" : txtEmpresa.Text;
                nuevo.FechaNacimiento = dtpCumplea�os.Value;

                nuevo.Telefonos = listaTxtTelefonos
                    .Select(t => t.Text)
                    .Where(t => !string.IsNullOrWhiteSpace(t) && t != "Tel�fono" && t != "Tel�fono adicional")
                    .ToList();

                Random r = new Random();
                Color colorFondo = Color.FromArgb(r.Next(50, 200), r.Next(50, 200), r.Next(50, 200));
                nuevo.ColorHex = ColorTranslator.ToHtml(colorFondo);

                GuardarEnJson(nuevo);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar el contacto: " + ex.Message);
            }
        }

        private void GuardarEnJson(Contacto nuevo)
        {
            try
            {
                string ruta = Path.Combine(Application.StartupPath, "agenda.json");
                List<Contacto> lista = new List<Contacto>();
                if (File.Exists(ruta))
                {
                    string contenido = File.ReadAllText(ruta);
                    lista = JsonConvert.DeserializeObject<List<Contacto>>(contenido) ?? new List<Contacto>();
                }
                lista.Add(nuevo);
                File.WriteAllText(ruta, JsonConvert.SerializeObject(lista, Formatting.Indented));
            }
            catch (IOException ex)
            {
                MessageBox.Show("Error de acceso al archivo: " + ex.Message);
            }
        }

        private void imgBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ConfigurarPlaceholder(TextBox txt, string texto)
        {
            try
            {
                txt.Text = texto;
                txt.ForeColor = Color.Gray;

                txt.Enter += (s, e) =>
                {
                    if (txt.Text == texto)
                    {
                        txt.Text = "";
                        txt.ForeColor = Color.Black;
                    }
                };

                txt.Leave += (s, e) =>
                {
                    if (string.IsNullOrWhiteSpace(txt.Text))
                    {
                        txt.Text = texto;
                        txt.ForeColor = Color.Gray;
                    }
                };
            }
            catch (Exception) { }
        }
    }
}