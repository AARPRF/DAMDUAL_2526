﻿using System;
using System.Collections.Generic;

namespace LibreriaAgenda
{
    public class Contacto
    {
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string Empresa { get; set; }
        public string Email { get; set; }
        public DateTime FechaNacimiento { get; set; }

        public List<string> Telefonos { get; set; } = new List<string>();

        public string RutaImagen { get; set; }
        public string ColorHex { get; set; }

        public Contacto() { }
    }
}