﻿namespace LibreriaAgenda
{
    partial class FilaContacto
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }


        #region Código generado por el Diseñador de componentes

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.picAvatar = new System.Windows.Forms.PictureBox();
            this.pnlDetalles = new System.Windows.Forms.Panel();
            this.lblTelefonoReal = new System.Windows.Forms.Label();
            this.lblEmailReal = new System.Windows.Forms.Label();
            this.lblNombreReal = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar)).BeginInit();
            this.SuspendLayout();
            // 
            // picAvatar
            // 
            this.picAvatar.Location = new System.Drawing.Point(3, 16);
            this.picAvatar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.picAvatar.Name = "picAvatar";
            this.picAvatar.Size = new System.Drawing.Size(110, 80);
            this.picAvatar.TabIndex = 0;
            this.picAvatar.TabStop = false;
            // 
            // pnlDetalles
            // 
            this.pnlDetalles.Location = new System.Drawing.Point(53, 195);
            this.pnlDetalles.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pnlDetalles.Name = "pnlDetalles";
            this.pnlDetalles.Size = new System.Drawing.Size(952, 347);
            this.pnlDetalles.TabIndex = 4;
            this.pnlDetalles.Visible = false;
            // 
            // lblTelefonoReal
            // 
            this.lblTelefonoReal.Location = new System.Drawing.Point(878, 29);
            this.lblTelefonoReal.Name = "lblTelefonoReal";
            this.lblTelefonoReal.Size = new System.Drawing.Size(138, 75);
            this.lblTelefonoReal.TabIndex = 3;
            this.lblTelefonoReal.Text = "label1";
            // 
            // lblEmailReal
            // 
            this.lblEmailReal.Location = new System.Drawing.Point(343, 29);
            this.lblEmailReal.Name = "lblEmailReal";
            this.lblEmailReal.Size = new System.Drawing.Size(272, 75);
            this.lblEmailReal.TabIndex = 2;
            this.lblEmailReal.Text = "label1";
            // 
            // lblNombreReal
            // 
            this.lblNombreReal.BackColor = System.Drawing.SystemColors.Control;
            this.lblNombreReal.Location = new System.Drawing.Point(152, 29);
            this.lblNombreReal.Name = "lblNombreReal";
            this.lblNombreReal.Size = new System.Drawing.Size(185, 75);
            this.lblNombreReal.TabIndex = 1;
            this.lblNombreReal.Text = "label1";
            // 
            // FilaContacto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblNombreReal);
            this.Controls.Add(this.lblEmailReal);
            this.Controls.Add(this.lblTelefonoReal);
            this.Controls.Add(this.pnlDetalles);
            this.Controls.Add(this.picAvatar);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FilaContacto";
            this.Size = new System.Drawing.Size(1066, 988);
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picAvatar;
        private System.Windows.Forms.Panel pnlDetalles;
        public System.Windows.Forms.Label lblEmailReal;
        public System.Windows.Forms.Label lblNombreReal;
        public System.Windows.Forms.Label lblTelefonoReal;
    }
}
