﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace LibreriaAgenda
{
    public partial class FilaContacto : UserControl
    {
        public FilaContacto()
        {
            InitializeComponent();
        }

        public void Configurar(Contacto contacto)
        {
            if (contacto == null) return;
            try
            {
                this.lblNombreReal.Text = (contacto.Nombre + " " + contacto.Apellidos).Trim();
                this.lblEmailReal.Text = contacto.Email ?? "";
                this.lblTelefonoReal.Text = (contacto.Telefonos != null && contacto.Telefonos.Count > 0)
                                            ? contacto.Telefonos[0] : "Sin teléfono";

                string inicial = !string.IsNullOrEmpty(contacto.Nombre) ? contacto.Nombre[0].ToString().ToUpper() : "?";
                Color colorFondo = string.IsNullOrEmpty(contacto.ColorHex)
                                   ? Color.SteelBlue : ColorTranslator.FromHtml(contacto.ColorHex);

                picAvatar.Width = 70;
                picAvatar.Height = 70;
                picAvatar.Image = CrearImagenConInicial(inicial, colorFondo);

                System.Drawing.Drawing2D.GraphicsPath gp = new System.Drawing.Drawing2D.GraphicsPath();
                gp.AddEllipse(0, 0, picAvatar.Width, picAvatar.Height);
                picAvatar.Region = new Region(gp);

                int topFijo = 15;
                picAvatar.Left = 10;
                picAvatar.Top = topFijo;
                lblNombreReal.Left = 90;
                lblNombreReal.Top = topFijo + 10;
                lblEmailReal.Left = 250;
                lblEmailReal.Top = lblNombreReal.Top;
                lblTelefonoReal.Left = 550;
                lblTelefonoReal.Top = lblNombreReal.Top;

                picAvatar.BringToFront();
                lblNombreReal.BringToFront();
                lblEmailReal.BringToFront();
                lblTelefonoReal.BringToFront();
                this.lblNombreReal.BackColor = Color.Transparent;
                this.lblEmailReal.BackColor = Color.Transparent;
                this.lblTelefonoReal.BackColor = Color.Transparent;

                this.lblNombreReal.BringToFront();
            }
            catch (Exception) { }
        }

        private Bitmap CrearImagenConInicial(string letra, Color fondo)
        {
            try
            {
                Bitmap bmp = new Bitmap(70, 70);
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                    g.Clear(fondo);
                    Font fuente = new Font("Segoe UI", 22, FontStyle.Bold);
                    StringFormat formato = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
                    g.DrawString(letra, fuente, Brushes.White, new Rectangle(0, 0, 70, 70), formato);
                }
                return bmp;
            }
            catch (Exception) { return new Bitmap(70, 70); }
        }
    }
}