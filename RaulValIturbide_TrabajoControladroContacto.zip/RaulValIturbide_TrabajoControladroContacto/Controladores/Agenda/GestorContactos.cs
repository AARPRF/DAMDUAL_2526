﻿using Controlador;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Agenda
{
    internal class GestorContactos
    {
        string rutaArchivo =  "Contactos.txt";
        public static List<Contacto> listaContactos = new List<Contacto>();




        //El CSV ES: NOMBRE,APELLIDOS,CORREO,TLF1,TLF2,TLF3,RUTAIMAGEN
        //AUNQUE NO HAYA TELEFONOS DEBEN APARECER LAS COMILLAS
        public void CargarContactosCSV()
        {
            string[] lineas = File.ReadAllLines(rutaArchivo);

            foreach (string linea in lineas)
            {
                string[] atributos = linea.Split(',');

                Contacto contacto = new Contacto()
                {
                    Nombre = atributos[0],
                    Apellidos = atributos[1],
                    Email = atributos[2],
                    ListaTelefonos = new List<string>(),
                    imagen = Image.FromFile(atributos[6])
                };

                for (int i = 3; i < atributos.Length - 1; i++)
                {
                    if (!string.IsNullOrWhiteSpace(atributos[i]))
                    {
                        contacto.ListaTelefonos.Add(atributos[i]);
                    }
                }

                listaContactos.Add(contacto);
            }
        }


        public List<Contacto> DevolverLista()
        {
            return listaContactos;
        }
    }
}
