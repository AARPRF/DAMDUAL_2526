﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controlador
{
    //CLASE PARA GESTIONAR EL ASPECTO VISUAL DE LOS FORMULARIOS
    internal enum EstadoEnum
    {
        Edicion,
        Consulta
    }
}
