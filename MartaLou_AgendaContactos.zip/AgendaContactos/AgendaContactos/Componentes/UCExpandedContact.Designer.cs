﻿namespace AgendaContactos.Componentes
{
    partial class UCExpandedContact
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            pictureBoxFoto = new PictureBox();
            txtNombre = new TextBox();
            txtApellidos = new TextBox();
            txtEmpresa = new TextBox();
            txtDireccion = new TextBox();
            lblNombre = new Label();
            lblApellidos = new Label();
            lblEmpresa = new Label();
            lblDireccion = new Label();
            lblCumple = new Label();
            panelEmails = new FlowLayoutPanel();
            panelTelefonos = new FlowLayoutPanel();
            lblTel = new Label();
            lblEm = new Label();
            lblFecha = new Label();
            comboDia = new Guna.UI2.WinForms.Guna2ComboBox();
            btnSave = new Guna.UI2.WinForms.Guna2Button();
            btnEdit = new Guna.UI2.WinForms.Guna2Button();
            btnCancel = new Guna.UI2.WinForms.Guna2Button();
            btnDelete = new Guna.UI2.WinForms.Guna2Button();
            btnBack = new Guna.UI2.WinForms.Guna2CircleButton();
            btnAddTel = new Guna.UI2.WinForms.Guna2CircleButton();
            btnAddEmail = new Guna.UI2.WinForms.Guna2CircleButton();
            comboMes = new Guna.UI2.WinForms.Guna2ComboBox();
            comboAnio = new Guna.UI2.WinForms.Guna2ComboBox();
            ((System.ComponentModel.ISupportInitialize)pictureBoxFoto).BeginInit();
            SuspendLayout();
            // 
            // pictureBoxFoto
            // 
            pictureBoxFoto.Location = new Point(24, 100);
            pictureBoxFoto.Name = "pictureBoxFoto";
            pictureBoxFoto.Size = new Size(262, 242);
            pictureBoxFoto.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxFoto.TabIndex = 4;
            pictureBoxFoto.TabStop = false;
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(405, 103);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(341, 27);
            txtNombre.TabIndex = 5;
            // 
            // txtApellidos
            // 
            txtApellidos.Location = new Point(405, 154);
            txtApellidos.Name = "txtApellidos";
            txtApellidos.Size = new Size(341, 27);
            txtApellidos.TabIndex = 6;
            // 
            // txtEmpresa
            // 
            txtEmpresa.Location = new Point(405, 207);
            txtEmpresa.Name = "txtEmpresa";
            txtEmpresa.Size = new Size(341, 27);
            txtEmpresa.TabIndex = 7;
            // 
            // txtDireccion
            // 
            txtDireccion.Location = new Point(405, 262);
            txtDireccion.Name = "txtDireccion";
            txtDireccion.Size = new Size(341, 27);
            txtDireccion.TabIndex = 8;
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Font = new Font("Cambria", 10.8F, FontStyle.Bold | FontStyle.Italic);
            lblNombre.ForeColor = Color.FromArgb(73, 37, 10);
            lblNombre.Location = new Point(287, 110);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(75, 21);
            lblNombre.TabIndex = 9;
            lblNombre.Text = "Nombre";
            // 
            // lblApellidos
            // 
            lblApellidos.AutoSize = true;
            lblApellidos.Font = new Font("Cambria", 10.8F, FontStyle.Bold | FontStyle.Italic);
            lblApellidos.ForeColor = Color.FromArgb(73, 37, 10);
            lblApellidos.Location = new Point(287, 161);
            lblApellidos.Name = "lblApellidos";
            lblApellidos.Size = new Size(83, 21);
            lblApellidos.TabIndex = 10;
            lblApellidos.Text = "Apellidos";
            // 
            // lblEmpresa
            // 
            lblEmpresa.AutoSize = true;
            lblEmpresa.Font = new Font("Cambria", 10.8F, FontStyle.Bold | FontStyle.Italic);
            lblEmpresa.ForeColor = Color.FromArgb(73, 37, 10);
            lblEmpresa.Location = new Point(287, 214);
            lblEmpresa.Name = "lblEmpresa";
            lblEmpresa.Size = new Size(81, 21);
            lblEmpresa.TabIndex = 11;
            lblEmpresa.Text = "Empresa";
            // 
            // lblDireccion
            // 
            lblDireccion.AutoSize = true;
            lblDireccion.Font = new Font("Cambria", 10.8F, FontStyle.Bold | FontStyle.Italic);
            lblDireccion.ForeColor = Color.FromArgb(73, 37, 10);
            lblDireccion.Location = new Point(287, 269);
            lblDireccion.Name = "lblDireccion";
            lblDireccion.Size = new Size(86, 21);
            lblDireccion.TabIndex = 12;
            lblDireccion.Text = "Direccion";
            // 
            // lblCumple
            // 
            lblCumple.AutoSize = true;
            lblCumple.Font = new Font("Cambria", 10.8F, FontStyle.Bold | FontStyle.Italic);
            lblCumple.ForeColor = Color.FromArgb(73, 37, 10);
            lblCumple.Location = new Point(287, 317);
            lblCumple.Name = "lblCumple";
            lblCumple.Size = new Size(110, 21);
            lblCumple.TabIndex = 14;
            lblCumple.Text = "Cumpleaños";
            // 
            // panelEmails
            // 
            panelEmails.AutoScroll = true;
            panelEmails.Location = new Point(389, 396);
            panelEmails.Name = "panelEmails";
            panelEmails.Size = new Size(343, 217);
            panelEmails.TabIndex = 18;
            // 
            // panelTelefonos
            // 
            panelTelefonos.AutoScroll = true;
            panelTelefonos.Location = new Point(24, 396);
            panelTelefonos.Name = "panelTelefonos";
            panelTelefonos.Size = new Size(343, 217);
            panelTelefonos.TabIndex = 19;
            // 
            // lblTel
            // 
            lblTel.AutoSize = true;
            lblTel.Font = new Font("Cambria", 10.8F, FontStyle.Bold | FontStyle.Italic);
            lblTel.ForeColor = Color.FromArgb(73, 37, 10);
            lblTel.Location = new Point(24, 362);
            lblTel.Name = "lblTel";
            lblTel.Size = new Size(88, 21);
            lblTel.TabIndex = 20;
            lblTel.Text = "Telefonos";
            // 
            // lblEm
            // 
            lblEm.AutoSize = true;
            lblEm.Font = new Font("Cambria", 10.8F, FontStyle.Bold | FontStyle.Italic);
            lblEm.Location = new Point(389, 362);
            lblEm.Name = "lblEm";
            lblEm.Size = new Size(64, 21);
            lblEm.TabIndex = 21;
            lblEm.Text = "Emails";
            // 
            // lblFecha
            // 
            lblFecha.AutoSize = true;
            lblFecha.Location = new Point(421, 317);
            lblFecha.Name = "lblFecha";
            lblFecha.Size = new Size(0, 20);
            lblFecha.TabIndex = 24;
            // 
            // comboDia
            // 
            comboDia.BackColor = Color.Transparent;
            comboDia.BorderRadius = 20;
            comboDia.CustomizableEdges = customizableEdges1;
            comboDia.DrawMode = DrawMode.OwnerDrawFixed;
            comboDia.DropDownStyle = ComboBoxStyle.DropDownList;
            comboDia.FocusedColor = Color.FromArgb(94, 148, 255);
            comboDia.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            comboDia.Font = new Font("Segoe UI", 8F);
            comboDia.ForeColor = Color.FromArgb(68, 88, 112);
            comboDia.ItemHeight = 30;
            comboDia.Location = new Point(405, 310);
            comboDia.Name = "comboDia";
            comboDia.ShadowDecoration.CustomizableEdges = customizableEdges2;
            comboDia.Size = new Size(85, 36);
            comboDia.TabIndex = 25;
            // 
            // btnSave
            // 
            btnSave.BorderRadius = 20;
            btnSave.CustomizableEdges = customizableEdges3;
            btnSave.DisabledState.BorderColor = Color.DarkGray;
            btnSave.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSave.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSave.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSave.FillColor = Color.FromArgb(205, 177, 171);
            btnSave.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSave.ForeColor = Color.FromArgb(73, 37, 10);
            btnSave.Location = new Point(360, 19);
            btnSave.Name = "btnSave";
            btnSave.ShadowDecoration.BorderRadius = 20;
            btnSave.ShadowDecoration.Color = Color.FromArgb(64, 0, 0);
            btnSave.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnSave.Size = new Size(113, 49);
            btnSave.TabIndex = 26;
            btnSave.Text = "Guardar";
            // 
            // btnEdit
            // 
            btnEdit.BorderRadius = 20;
            btnEdit.CustomizableEdges = customizableEdges5;
            btnEdit.DisabledState.BorderColor = Color.DarkGray;
            btnEdit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnEdit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnEdit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnEdit.FillColor = Color.FromArgb(205, 177, 171);
            btnEdit.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEdit.ForeColor = Color.FromArgb(73, 37, 10);
            btnEdit.Location = new Point(488, 19);
            btnEdit.Name = "btnEdit";
            btnEdit.ShadowDecoration.BorderRadius = 20;
            btnEdit.ShadowDecoration.Color = Color.FromArgb(64, 0, 0);
            btnEdit.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnEdit.Size = new Size(113, 49);
            btnEdit.TabIndex = 28;
            btnEdit.Text = "Editar";
            // 
            // btnCancel
            // 
            btnCancel.BorderRadius = 20;
            btnCancel.CustomizableEdges = customizableEdges7;
            btnCancel.DisabledState.BorderColor = Color.DarkGray;
            btnCancel.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCancel.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCancel.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCancel.FillColor = Color.FromArgb(205, 177, 171);
            btnCancel.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCancel.ForeColor = Color.FromArgb(73, 37, 10);
            btnCancel.Location = new Point(488, 19);
            btnCancel.Name = "btnCancel";
            btnCancel.ShadowDecoration.BorderRadius = 20;
            btnCancel.ShadowDecoration.Color = Color.FromArgb(64, 0, 0);
            btnCancel.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnCancel.Size = new Size(113, 49);
            btnCancel.TabIndex = 29;
            btnCancel.Text = "Cancelar";
            // 
            // btnDelete
            // 
            btnDelete.BorderRadius = 20;
            btnDelete.CustomizableEdges = customizableEdges9;
            btnDelete.DisabledState.BorderColor = Color.DarkGray;
            btnDelete.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDelete.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDelete.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDelete.FillColor = Color.FromArgb(73, 37, 10);
            btnDelete.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDelete.ForeColor = Color.FromArgb(205, 177, 171);
            btnDelete.Location = new Point(619, 19);
            btnDelete.Name = "btnDelete";
            btnDelete.ShadowDecoration.BorderRadius = 20;
            btnDelete.ShadowDecoration.Color = Color.FromArgb(64, 0, 0);
            btnDelete.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnDelete.Size = new Size(113, 49);
            btnDelete.TabIndex = 30;
            btnDelete.Text = "Eliminar";
            // 
            // btnBack
            // 
            btnBack.DisabledState.BorderColor = Color.DarkGray;
            btnBack.DisabledState.CustomBorderColor = Color.DarkGray;
            btnBack.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnBack.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnBack.FillColor = Color.FromArgb(227, 211, 208);
            btnBack.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBack.ForeColor = Color.FromArgb(73, 37, 10);
            btnBack.Location = new Point(24, 19);
            btnBack.Name = "btnBack";
            btnBack.ShadowDecoration.CustomizableEdges = customizableEdges11;
            btnBack.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            btnBack.Size = new Size(49, 49);
            btnBack.TabIndex = 31;
            btnBack.Text = "⮜";
            // 
            // btnAddTel
            // 
            btnAddTel.DisabledState.BorderColor = Color.DarkGray;
            btnAddTel.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAddTel.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAddTel.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAddTel.FillColor = Color.FromArgb(227, 211, 208);
            btnAddTel.Font = new Font("Segoe UI Black", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAddTel.ForeColor = Color.FromArgb(73, 37, 10);
            btnAddTel.Location = new Point(114, 362);
            btnAddTel.Name = "btnAddTel";
            btnAddTel.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btnAddTel.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            btnAddTel.Size = new Size(30, 27);
            btnAddTel.TabIndex = 32;
            btnAddTel.Text = "+";
            btnAddTel.TextOffset = new Point(1, -1);
            // 
            // btnAddEmail
            // 
            btnAddEmail.DisabledState.BorderColor = Color.DarkGray;
            btnAddEmail.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAddEmail.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAddEmail.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAddEmail.FillColor = Color.FromArgb(227, 211, 208);
            btnAddEmail.Font = new Font("Segoe UI Black", 7.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAddEmail.ForeColor = Color.FromArgb(73, 37, 10);
            btnAddEmail.Location = new Point(456, 363);
            btnAddEmail.Name = "btnAddEmail";
            btnAddEmail.ShadowDecoration.CustomizableEdges = customizableEdges13;
            btnAddEmail.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            btnAddEmail.Size = new Size(30, 27);
            btnAddEmail.TabIndex = 33;
            btnAddEmail.Text = "+";
            btnAddEmail.TextOffset = new Point(1, -1);
            // 
            // comboMes
            // 
            comboMes.BackColor = Color.Transparent;
            comboMes.BorderRadius = 20;
            comboMes.CustomizableEdges = customizableEdges14;
            comboMes.DrawMode = DrawMode.OwnerDrawFixed;
            comboMes.DropDownStyle = ComboBoxStyle.DropDownList;
            comboMes.FocusedColor = Color.FromArgb(94, 148, 255);
            comboMes.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            comboMes.Font = new Font("Segoe UI", 8F);
            comboMes.ForeColor = Color.FromArgb(68, 88, 112);
            comboMes.ItemHeight = 30;
            comboMes.Location = new Point(488, 310);
            comboMes.Name = "comboMes";
            comboMes.ShadowDecoration.CustomizableEdges = customizableEdges15;
            comboMes.Size = new Size(139, 36);
            comboMes.TabIndex = 34;
            // 
            // comboAnio
            // 
            comboAnio.BackColor = Color.Transparent;
            comboAnio.BorderRadius = 20;
            comboAnio.CustomizableEdges = customizableEdges16;
            comboAnio.DrawMode = DrawMode.OwnerDrawFixed;
            comboAnio.DropDownStyle = ComboBoxStyle.DropDownList;
            comboAnio.FocusedColor = Color.FromArgb(94, 148, 255);
            comboAnio.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            comboAnio.Font = new Font("Segoe UI", 8F);
            comboAnio.ForeColor = Color.FromArgb(68, 88, 112);
            comboAnio.ItemHeight = 30;
            comboAnio.Location = new Point(626, 310);
            comboAnio.Name = "comboAnio";
            comboAnio.ShadowDecoration.CustomizableEdges = customizableEdges17;
            comboAnio.Size = new Size(120, 36);
            comboAnio.TabIndex = 35;
            // 
            // UCExpandedContact
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(239, 230, 228);
            Controls.Add(comboMes);
            Controls.Add(comboAnio);
            Controls.Add(btnAddEmail);
            Controls.Add(btnAddTel);
            Controls.Add(btnBack);
            Controls.Add(btnDelete);
            Controls.Add(btnCancel);
            Controls.Add(btnEdit);
            Controls.Add(btnSave);
            Controls.Add(comboDia);
            Controls.Add(lblFecha);
            Controls.Add(lblEm);
            Controls.Add(lblTel);
            Controls.Add(panelTelefonos);
            Controls.Add(panelEmails);
            Controls.Add(lblCumple);
            Controls.Add(lblDireccion);
            Controls.Add(lblEmpresa);
            Controls.Add(lblApellidos);
            Controls.Add(lblNombre);
            Controls.Add(txtDireccion);
            Controls.Add(txtEmpresa);
            Controls.Add(txtApellidos);
            Controls.Add(txtNombre);
            Controls.Add(pictureBoxFoto);
            Name = "UCExpandedContact";
            Size = new Size(764, 704);
            ((System.ComponentModel.ISupportInitialize)pictureBoxFoto).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBoxFoto;
        private TextBox txtNombre;
        private TextBox txtApellidos;
        private TextBox txtEmpresa;
        private TextBox txtDireccion;
        private Label lblNombre;
        private Label lblApellidos;
        private Label lblEmpresa;
        private Label lblDireccion;
        private Label lblCumple;
        private FlowLayoutPanel panelEmails;
        private FlowLayoutPanel panelTelefonos;
        private Label lblTel;
        private Label lblEm;
        private Label lblFecha;
        private Guna.UI2.WinForms.Guna2ComboBox comboDia;
        private Guna.UI2.WinForms.Guna2Button btnSave;
        private Guna.UI2.WinForms.Guna2Button btnEdit;
        private Guna.UI2.WinForms.Guna2Button btnCancel;
        private Guna.UI2.WinForms.Guna2Button btnDelete;
        private Guna.UI2.WinForms.Guna2CircleButton btnBack;
        private Guna.UI2.WinForms.Guna2CircleButton btnAddTel;
        private Guna.UI2.WinForms.Guna2CircleButton btnAddEmail;
        private Guna.UI2.WinForms.Guna2ComboBox comboMes;
        private Guna.UI2.WinForms.Guna2ComboBox comboAnio;
    }
}
