﻿namespace AgendaContactos.Componentes
{
    partial class UCContactList
    {
        /// <summary> 
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panelContacts = new FlowLayoutPanel();
            panelABC = new FlowLayoutPanel();
            btnNew = new Guna.UI2.WinForms.Guna2Button();
            SuspendLayout();
            // 
            // panelContacts
            // 
            panelContacts.AutoScroll = true;
            panelContacts.Location = new Point(21, 68);
            panelContacts.Name = "panelContacts";
            panelContacts.Size = new Size(617, 667);
            panelContacts.TabIndex = 1;
            // 
            // panelABC
            // 
            panelABC.FlowDirection = FlowDirection.TopDown;
            panelABC.Location = new Point(644, 68);
            panelABC.Name = "panelABC";
            panelABC.Size = new Size(55, 692);
            panelABC.TabIndex = 2;
            // 
            // btnNew
            // 
            btnNew.BorderRadius = 20;
            btnNew.CustomizableEdges = customizableEdges1;
            btnNew.DisabledState.BorderColor = Color.DarkGray;
            btnNew.DisabledState.CustomBorderColor = Color.DarkGray;
            btnNew.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnNew.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnNew.FillColor = Color.FromArgb(205, 177, 171);
            btnNew.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnNew.ForeColor = Color.FromArgb(73, 37, 10);
            btnNew.Location = new Point(476, 9);
            btnNew.Name = "btnNew";
            btnNew.ShadowDecoration.BorderRadius = 20;
            btnNew.ShadowDecoration.Color = Color.FromArgb(64, 0, 0);
            btnNew.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnNew.Size = new Size(162, 49);
            btnNew.TabIndex = 27;
            btnNew.Text = "Nuevo Contacto";
            // 
            // UCContactList
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(239, 230, 228);
            Controls.Add(btnNew);
            Controls.Add(panelABC);
            Controls.Add(panelContacts);
            Name = "UCContactList";
            Size = new Size(723, 1116);
            ResumeLayout(false);
        }

        #endregion

        private FlowLayoutPanel panelContacts;
        private FlowLayoutPanel panelABC;
        private Guna.UI2.WinForms.Guna2Button btnNew;
    }
}
