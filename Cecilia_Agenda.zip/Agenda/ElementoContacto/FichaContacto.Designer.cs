﻿namespace ElementoContacto
{


        partial class FichaContacto
        {
            /// <summary> 
            /// Variable del diseñador necesaria.
            /// </summary>
            private System.ComponentModel.IContainer components = null;

            /// <summary> 
            /// Limpiar los recursos que se estén usando.
            /// </summary>
            /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
            protected override void Dispose(bool disposing)
            {
                if (disposing && (components != null))
                {
                    components.Dispose();
                }
                base.Dispose(disposing);
            }

            #region Código generado por el Diseñador de componentes

            private void InitializeComponent()
            {
            this.panelPlaceholder = new System.Windows.Forms.Panel();
            this.pbox_imagen = new System.Windows.Forms.PictureBox();
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblTelefono = new System.Windows.Forms.Label();
            this.btn_ampliar = new System.Windows.Forms.Button();
            this.txtbNombre = new System.Windows.Forms.TextBox();
            this.txtbTelefono = new System.Windows.Forms.TextBox();
            this.lblApellidos = new System.Windows.Forms.Label();
            this.txtbApellidos = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtbEmail = new System.Windows.Forms.TextBox();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.panelTelefonos = new System.Windows.Forms.Panel();
            this.btnAnadirTelefono = new System.Windows.Forms.Button();
            this.btnCambiarFoto = new System.Windows.Forms.Button();
            this.panelPlaceholder.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_imagen)).BeginInit();
            this.SuspendLayout();
            // 
            // panelPlaceholder
            // 
            this.panelPlaceholder.BackColor = System.Drawing.Color.LightGray;
            this.panelPlaceholder.Controls.Add(this.pbox_imagen);
            this.panelPlaceholder.Location = new System.Drawing.Point(10, 10);
            this.panelPlaceholder.Name = "panelPlaceholder";
            this.panelPlaceholder.Size = new System.Drawing.Size(180, 180);
            this.panelPlaceholder.TabIndex = 0;
            // 
            // pbox_imagen
            // 
            this.pbox_imagen.BackColor = System.Drawing.Color.Transparent;
            this.pbox_imagen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbox_imagen.Location = new System.Drawing.Point(0, 0);
            this.pbox_imagen.Name = "pbox_imagen";
            this.pbox_imagen.Size = new System.Drawing.Size(180, 180);
            this.pbox_imagen.TabIndex = 1;
            this.pbox_imagen.TabStop = false;
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.Location = new System.Drawing.Point(200, 30);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(105, 26);
            this.lblNombre.TabIndex = 2;
            this.lblNombre.Text = "NOMBRE";
            // 
            // lblTelefono
            // 
            this.lblTelefono.AutoSize = true;
            this.lblTelefono.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefono.Location = new System.Drawing.Point(200, 90);
            this.lblTelefono.Name = "lblTelefono";
            this.lblTelefono.Size = new System.Drawing.Size(124, 26);
            this.lblTelefono.TabIndex = 3;
            this.lblTelefono.Text = "TELÉFONO";
            // 
            // btn_ampliar
            // 
            this.btn_ampliar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ampliar.Location = new System.Drawing.Point(420, 160);
            this.btn_ampliar.Name = "btn_ampliar";
            this.btn_ampliar.Size = new System.Drawing.Size(40, 30);
            this.btn_ampliar.TabIndex = 4;
            this.btn_ampliar.Text = "+";
            this.btn_ampliar.UseVisualStyleBackColor = true;
            // 
            // txtbNombre
            // 
            this.txtbNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbNombre.Location = new System.Drawing.Point(200, 60);
            this.txtbNombre.Name = "txtbNombre";
            this.txtbNombre.Size = new System.Drawing.Size(250, 30);
            this.txtbNombre.TabIndex = 5;
            this.txtbNombre.Visible = false;
            // 
            // txtbTelefono
            // 
            this.txtbTelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbTelefono.Location = new System.Drawing.Point(200, 120);
            this.txtbTelefono.Name = "txtbTelefono";
            this.txtbTelefono.Size = new System.Drawing.Size(250, 30);
            this.txtbTelefono.TabIndex = 6;
            this.txtbTelefono.Visible = false;
            // 
            // lblApellidos
            // 
            this.lblApellidos.AutoSize = true;
            this.lblApellidos.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApellidos.Location = new System.Drawing.Point(200, 164);
            this.lblApellidos.Name = "lblApellidos";
            this.lblApellidos.Size = new System.Drawing.Size(130, 26);
            this.lblApellidos.TabIndex = 7;
            this.lblApellidos.Text = "APELLIDOS";
            this.lblApellidos.Visible = false;
            // 
            // txtbApellidos
            // 
            this.txtbApellidos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbApellidos.Location = new System.Drawing.Point(200, 200);
            this.txtbApellidos.Name = "txtbApellidos";
            this.txtbApellidos.Size = new System.Drawing.Size(250, 30);
            this.txtbApellidos.TabIndex = 8;
            this.txtbApellidos.Visible = false;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("MV Boli", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(200, 233);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(90, 26);
            this.lblEmail.TabIndex = 9;
            this.lblEmail.Text = "E-MAIL";
            this.lblEmail.Visible = false;
            // 
            // txtbEmail
            // 
            this.txtbEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbEmail.Location = new System.Drawing.Point(200, 270);
            this.txtbEmail.Name = "txtbEmail";
            this.txtbEmail.Size = new System.Drawing.Size(250, 30);
            this.txtbEmail.TabIndex = 10;
            this.txtbEmail.Visible = false;
            // 
            // btnGuardar
            // 
            this.btnGuardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardar.Location = new System.Drawing.Point(391, 10);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(124, 30);
            this.btnGuardar.TabIndex = 11;
            this.btnGuardar.Text = "GUARDAR";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Visible = false;
            // 
            // panelTelefonos
            // 
            this.panelTelefonos.Location = new System.Drawing.Point(200, 350);
            this.panelTelefonos.Name = "panelTelefonos";
            this.panelTelefonos.Size = new System.Drawing.Size(250, 70);
            this.panelTelefonos.TabIndex = 12;
            this.panelTelefonos.Visible = false;
            // 
            // btnAnadirTelefono
            // 
            this.btnAnadirTelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnadirTelefono.Location = new System.Drawing.Point(200, 430);
            this.btnAnadirTelefono.Name = "btnAnadirTelefono";
            this.btnAnadirTelefono.Size = new System.Drawing.Size(250, 30);
            this.btnAnadirTelefono.TabIndex = 13;
            this.btnAnadirTelefono.Text = "AÑADIR TELÉFONO";
            this.btnAnadirTelefono.UseVisualStyleBackColor = true;
            this.btnAnadirTelefono.Visible = false;
            // 
            // btnCambiarFoto
            // 
            this.btnCambiarFoto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCambiarFoto.Location = new System.Drawing.Point(39, 207);
            this.btnCambiarFoto.Name = "btnCambiarFoto";
            this.btnCambiarFoto.Size = new System.Drawing.Size(96, 41);
            this.btnCambiarFoto.TabIndex = 14;
            this.btnCambiarFoto.Text = "Cambiar foto";
            this.btnCambiarFoto.UseVisualStyleBackColor = true;
            this.btnCambiarFoto.Visible = false;
            // 
            // FichaContacto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PapayaWhip;
            this.Controls.Add(this.btnCambiarFoto);
            this.Controls.Add(this.btnAnadirTelefono);
            this.Controls.Add(this.panelTelefonos);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.txtbEmail);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtbApellidos);
            this.Controls.Add(this.lblApellidos);
            this.Controls.Add(this.txtbTelefono);
            this.Controls.Add(this.txtbNombre);
            this.Controls.Add(this.btn_ampliar);
            this.Controls.Add(this.lblTelefono);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.panelPlaceholder);
            this.Name = "FichaContacto";
            this.Size = new System.Drawing.Size(545, 484);
            this.panelPlaceholder.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbox_imagen)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

            }

            #endregion

            private System.Windows.Forms.Panel panelPlaceholder;
            private System.Windows.Forms.PictureBox pbox_imagen;
            private System.Windows.Forms.Label lblNombre;
            private System.Windows.Forms.Label lblTelefono;
            private System.Windows.Forms.Button btn_ampliar;
            private System.Windows.Forms.TextBox txtbNombre;
            private System.Windows.Forms.TextBox txtbTelefono;
            private System.Windows.Forms.Label lblApellidos;
            private System.Windows.Forms.TextBox txtbApellidos;
            private System.Windows.Forms.Label lblEmail;
            private System.Windows.Forms.TextBox txtbEmail;
            private System.Windows.Forms.Button btnGuardar;
            private System.Windows.Forms.Panel panelTelefonos;
            private System.Windows.Forms.Button btnAnadirTelefono;
            private System.Windows.Forms.Button btnCambiarFoto;
        }
    }