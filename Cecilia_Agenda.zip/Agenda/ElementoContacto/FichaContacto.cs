﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace ElementoContacto
{

        /// <summary>
        /// Componente reutilizable para una ficha de contacto con dos modos:
        /// - Compacto: solo lectura.
        /// - Expandido: edición completa con campos dinámicos.
        /// </summary>
        public partial class FichaContacto : UserControl
        {
            private bool _modoExpandido = false;
            private List<string> _telefonosExtras = new List<string>();
            private const int MAX_TELEFONOS_EXTRAS = 2;

        // Propiedades públicas para acceder a los datos del contacto
        public string Nombre { get; set; } = "";
            public string Apellidos { get; set; } = "";
            public string Email { get; set; } = "";
            public string TelefonoPrincipal { get; set; } = "";

            public List<string> Telefonos =>
                new List<string> { TelefonoPrincipal }
                .Concat(_telefonosExtras.FindAll(t => !string.IsNullOrWhiteSpace(t)))
                .ToList();

            public FichaContacto()
            {
                InitializeComponent();
                InicializarComponente();
            }

            private void InicializarComponente()
            {
                // Configurar placeholder seguro 
                panelPlaceholder.BackColor = Color.LightGray;
                try
                {
                    if (Properties.Resources.Placeholder_Imagen != null)
                    {
                        panelPlaceholder.BackgroundImage = Properties.Resources.Placeholder_Imagen;
                        panelPlaceholder.BackgroundImageLayout = ImageLayout.Stretch;
                    }
                }
                catch (Exception ex)
                {
                    // Registrar el error para depuración y asegurar un estado visual coherente.
                    System.Diagnostics.Debug.WriteLine($"FichaContacto: error al cargar recurso Placeholder_Imagen: {ex}");
                    panelPlaceholder.BackgroundImage = null;
                    panelPlaceholder.BackgroundImageLayout = ImageLayout.None;
                    panelPlaceholder.BackColor = Color.LightGray;
                }

                // Conectar eventos
                btn_ampliar.Click += BtnAmpliar_Click;
                btnGuardar.Click += BtnGuardar_Click;
                btnAnadirTelefono.Click += BtnAnadirTelefono_Click;
                btnCambiarFoto.Click += BtnCambiarFoto_Click;

                // Iniciar en modo compacto
                MostrarModoCompacto();
            }

            private void BtnAmpliar_Click(object sender, EventArgs e)
            {
                AlternarModo();
            }

            private void AlternarModo()
            {
                if (_modoExpandido)
                    MostrarModoCompacto();
                else
                    MostrarModoExpandido();
            }

        private void MostrarModoCompacto()
        {
            _modoExpandido = false;
            this.Height = 200;

            // Mostrar labels SIEMPRE
            lblNombre.Visible = true;
            lblTelefono.Visible = true;
            lblApellidos.Visible = false;
            lblEmail.Visible = false;

            // Solo mostrar texto en compacto
            txtbNombre.Visible = false;
            txtbTelefono.Visible = false;
            txtbApellidos.Visible = false;
            txtbEmail.Visible = false;

            // Botones
            pbox_imagen.Visible = true;
            btn_ampliar.Visible = true;
            btnCambiarFoto.Visible = false;
            panelTelefonos.Visible = false;
            btnGuardar.Visible = false;
            btnAnadirTelefono.Visible = false;

            // Actualizar texto visible
            lblNombre.Text = "NOMBRE"; 
            lblTelefono.Text = "TELÉFONO"; 
        }

        private void MostrarModoExpandido()
        {
            _modoExpandido = true;
            this.Height = 480;

            // Labels siempre visibles
            lblNombre.Visible = true;
            lblTelefono.Visible = true;
            lblApellidos.Visible = true;
            lblEmail.Visible = true;

            // Mostrar campos editables
            txtbNombre.Visible = true;
            txtbTelefono.Visible = true;
            txtbApellidos.Visible = true;
            txtbEmail.Visible = true;

            // Botones
            pbox_imagen.Visible = true;
            btn_ampliar.Visible = true;
            btnCambiarFoto.Visible = true;
            panelTelefonos.Visible = true;
            btnGuardar.Visible = true;
            btnAnadirTelefono.Visible = true;


            // Restaurar etiquetas originales
            lblNombre.Text = "NOMBRE";
            lblTelefono.Text = "TELÉFONO";
            lblApellidos.Text = "APELLIDOS";
            lblEmail.Text = "E-MAIL";

            // Cargar datos en TextBox
            txtbNombre.Text = Nombre;
            txtbTelefono.Text = TelefonoPrincipal;
            txtbApellidos.Text = Apellidos;
            txtbEmail.Text = Email;

            RenderizarTelefonosExtras();
        }
        private void RenderizarTelefonosExtras()
            {
                panelTelefonos.Controls.Clear();
                for (int i = 0; i < _telefonosExtras.Count; i++)
                {
                    TextBox tb = new TextBox
                    {
                        Text = _telefonosExtras[i],
                        Size = new Size(200, 25),
                        Location = new Point(0, i * 30)
                    };
                    int index = i;
                    tb.TextChanged += (s, e) => _telefonosExtras[index] = tb.Text;
                    panelTelefonos.Controls.Add(tb);
                }
                btnAnadirTelefono.Enabled = _telefonosExtras.Count < MAX_TELEFONOS_EXTRAS;
            }

            private void BtnAnadirTelefono_Click(object sender, EventArgs e)
            {
                if (_telefonosExtras.Count < MAX_TELEFONOS_EXTRAS)
                {
                    _telefonosExtras.Add("");
                    RenderizarTelefonosExtras();
                }
            }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            Nombre = txtbNombre.Text.Trim();
            Apellidos = txtbApellidos.Text.Trim();
            Email = txtbEmail.Text.Trim();
            TelefonoPrincipal = txtbTelefono.Text.Trim();

            //  GUARDADO SIMULADO
            MessageBox.Show($"Contacto guardado:\n{Nombre} {Apellidos}\nTel: {TelefonoPrincipal}\nEmail: {Email}",
                            "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
        
        MostrarModoCompacto();
        }

            private void BtnCambiarFoto_Click(object sender, EventArgs e)
            {
                using (OpenFileDialog ofd = new OpenFileDialog())
                {
                    ofd.Filter = "Imágenes (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg|Todos los archivos (*.*)|*.*";
                    if (ofd.ShowDialog() == DialogResult.OK)
                    {
                        try
                        {
                            pbox_imagen.Image?.Dispose();
                            pbox_imagen.Image = Image.FromFile(ofd.FileName);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error al cargar la imagen:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }
    }