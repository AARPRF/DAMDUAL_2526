﻿namespace AgendaTest
{

        partial class Form1
        {
            /// <summary>
            /// Variable del diseñador necesaria.
            /// </summary>
            private System.ComponentModel.IContainer components = null;

            /// <summary>
            /// Limpiar los recursos que se estén usando.
            /// </summary>
            /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
            protected override void Dispose(bool disposing)
            {
                if (disposing && (components != null))
                {
                    components.Dispose();
                }
                base.Dispose(disposing);
            }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            fichaContacto1 = new FichaContacto();
            SuspendLayout();
            // 
            // fichaContacto1
            // 
            fichaContacto1.Apellidos = null;
            fichaContacto1.Email = null;
            fichaContacto1.Location = new Point(116, 111);
            fichaContacto1.Name = "fichaContacto1";
            fichaContacto1.Nombre = null;
            fichaContacto1.Size = new Size(188, 188);
            fichaContacto1.TabIndex = 0;
            fichaContacto1.TelefonoPrincipal = null;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(600, 550);
            Controls.Add(fichaContacto1);
            Name = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private FichaContacto fichaContacto1;
    }
    }