using System.Windows.Forms;

namespace AgendaTest
{

    //me da error al referenciar el proyecto ElementoContacto
    public class   UserControl
    {
        public string Nombre { get; set; } = string.Empty;
        public string TelefonoPrincipal { get; set; } = string.Empty;

    }
   
}