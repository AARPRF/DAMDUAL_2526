namespace AgendaTest
{
    using System;
    using System.Windows.Forms;

    public partial class Form1 : Form
    {
        private FichaContacto ficha;

        public Form1()
        {
            CrearFichaDeContacto();
        }

        private void CrearFichaDeContacto()
        {
            // Crear instancia del componente
            ficha = new FichaContacto();

            // A�adir al formulario
            this.Controls.Add(ficha);
            ficha.Location = new System.Drawing.Point(40, 40);
            ficha.Anchor = AnchorStyles.Top | AnchorStyles.Left;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            this.Text = "Prueba de Ficha de Contacto";
            this.Size = new System.Drawing.Size(600, 550);
            this.BackColor = System.Drawing.Color.White;
        }
    }

    public class FichaContacto : System.Windows.Forms.UserControl // <-- Cambiado aqu�
    {
        public string Nombre { get; set; }
        public string Apellidos { get; set; }
        public string TelefonoPrincipal { get; set; }
        public string Email { get; set; }
    }
}
