using AgendaControls.Controls;
using AgendaControls.Models;
using AgendaControls.Themes;

namespace AgendaControls.Dialogs;

/// <summary>
/// Diálogo modal para añadir o editar un número de teléfono.
/// </summary>
public class PhoneModal : BaseModal
{
    private readonly StyledTextBox _labelInput;
    private readonly StyledTextBox _phoneInput;
    private PhoneNumber? _phoneNumber;

    public PhoneNumber? Result => _phoneNumber;

    public PhoneModal(PhoneNumber? existingPhone = null)
    {
        Text = existingPhone == null ? "AÑADIR TELÉFONO" : "EDITAR TELÉFONO";
        SetContentSize(320, 220);

        // Title
        var titleLabel = new Label
        {
            Text = Text,
            Font = new Font("Segoe UI Semibold", 11f),
            ForeColor = ThemeManager.CurrentTheme.DarkText,
            AutoSize = true,
            Location = new Point(24, 24)
        };

        // Label input
        _labelInput = new StyledTextBox
        {
            Label = "ETIQUETA",
            Text = existingPhone?.Label ?? "Móvil",
            Location = new Point(24, 60),
            Size = new Size(272, 52)
        };

        // Phone input
        _phoneInput = new StyledTextBox
        {
            Label = "TELÉFONO",
            Text = existingPhone?.Number ?? "",
            Placeholder = "+34 XXX XXX XXX",
            Location = new Point(24, 120),
            Size = new Size(272, 52)
        };

        ContentPanel.Controls.Add(titleLabel);
        ContentPanel.Controls.Add(_labelInput);
        ContentPanel.Controls.Add(_phoneInput);

        if (existingPhone != null)
        {
            _phoneNumber = existingPhone;
        }
    }

    protected override bool ValidateInput()
    {
        if (string.IsNullOrWhiteSpace(_phoneInput.Text))
        {
            MessageBox.Show("Por favor, introduce un número de teléfono.", 
                "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            _phoneInput.Focus();
            return false;
        }

        _phoneNumber = new PhoneNumber
        {
            Id = _phoneNumber?.Id ?? Guid.NewGuid(),
            Label = string.IsNullOrWhiteSpace(_labelInput.Text) ? "Móvil" : _labelInput.Text,
            Number = _phoneInput.Text
        };

        return true;
    }
}

/// <summary>
/// Diálogo modal para añadir o editar una dirección de correo electrónico.
/// </summary>
public class EmailModal : BaseModal
{
    private readonly StyledTextBox _labelInput;
    private readonly StyledTextBox _emailInput;
    private EmailAddress? _emailAddress;

    public EmailAddress? Result => _emailAddress;

    public EmailModal(EmailAddress? existingEmail = null)
    {
        Text = existingEmail == null ? "AÑADIR E-MAIL" : "EDITAR E-MAIL";
        SetContentSize(320, 220);

        // Title
        var titleLabel = new Label
        {
            Text = Text,
            Font = new Font("Segoe UI Semibold", 11f),
            ForeColor = ThemeManager.CurrentTheme.DarkText,
            AutoSize = true,
            Location = new Point(24, 24)
        };

        // Label input
        _labelInput = new StyledTextBox
        {
            Label = "ETIQUETA",
            Text = existingEmail?.Label ?? "Personal",
            Location = new Point(24, 60),
            Size = new Size(272, 52)
        };

        // Email input
        _emailInput = new StyledTextBox
        {
            Label = "E-MAIL",
            Text = existingEmail?.Email ?? "",
            Placeholder = "correo@ejemplo.com",
            Location = new Point(24, 120),
            Size = new Size(272, 52)
        };

        ContentPanel.Controls.Add(titleLabel);
        ContentPanel.Controls.Add(_labelInput);
        ContentPanel.Controls.Add(_emailInput);

        if (existingEmail != null)
        {
            _emailAddress = existingEmail;
        }
    }

    protected override bool ValidateInput()
    {
        if (string.IsNullOrWhiteSpace(_emailInput.Text))
        {
            MessageBox.Show("Por favor, introduce un correo electrónico.", 
                "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            _emailInput.Focus();
            return false;
        }

        // Basic email validation
        if (!_emailInput.Text.Contains('@') || !_emailInput.Text.Contains('.'))
        {
            MessageBox.Show("Por favor, introduce un correo electrónico válido.", 
                "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            _emailInput.Focus();
            return false;
        }

        _emailAddress = new EmailAddress
        {
            Id = _emailAddress?.Id ?? Guid.NewGuid(),
            Label = string.IsNullOrWhiteSpace(_labelInput.Text) ? "Personal" : _labelInput.Text,
            Email = _emailInput.Text
        };

        return true;
    }
}

/// <summary>
/// Diálogo modal para añadir o editar una dirección.
/// </summary>
public class AddressModal : BaseModal
{
    private readonly StyledTextBox _labelInput;
    private readonly StyledTextBox _street1Input;
    private readonly StyledTextBox _street2Input;
    private readonly StyledTextBox _postalCodeInput;
    private readonly StyledTextBox _cityInput;
    private readonly StyledTextBox _provinceInput;
    private readonly StyledTextBox _countryInput;
    private PhysicalAddress? _address;

    public PhysicalAddress? Result => _address;

    public AddressModal(PhysicalAddress? existingAddress = null)
    {
        Text = existingAddress == null ? "AÑADIR DIRECCIÓN FÍSICA" : "EDITAR DIRECCIÓN";
        SetContentSize(360, 400);

        var titleLabel = new Label
        {
            Text = Text,
            Font = new Font("Segoe UI Semibold", 11f),
            ForeColor = ThemeManager.CurrentTheme.DarkText,
            AutoSize = true,
            Location = new Point(24, 20)
        };

        var yPos = 50;
        var spacing = 60;       // altura + margen
        var inputWidth = 312;
        var halfWidth = 148;

        _labelInput = new StyledTextBox
        {
            Label = "ETIQUETA",
            Text = existingAddress?.Label ?? "Casa",
            Location = new Point(24, yPos),
            Size = new Size(inputWidth, 52)   // altura suficiente para label + input
        };
        yPos += spacing;

        _street1Input = new StyledTextBox
        {
            Label = "CALLE 1",
            Text = existingAddress?.Street1 ?? "",
            Location = new Point(24, yPos),
            Size = new Size(inputWidth, 52)
        };
        yPos += spacing;

        _street2Input = new StyledTextBox
        {
            Label = "CALLE 2",
            Text = existingAddress?.Street2 ?? "",
            Location = new Point(24, yPos),
            Size = new Size(inputWidth, 52)
        };
        yPos += spacing;

        _postalCodeInput = new StyledTextBox
        {
            Label = "C.P.",
            Text = existingAddress?.PostalCode ?? "",
            Location = new Point(24, yPos),
            Size = new Size(halfWidth, 52)
        };

        _cityInput = new StyledTextBox
        {
            Label = "CIUDAD",
            Text = existingAddress?.City ?? "",
            Location = new Point(24 + halfWidth + 16, yPos),
            Size = new Size(halfWidth, 52)
        };
        yPos += spacing;

        _provinceInput = new StyledTextBox
        {
            Label = "PROVINCIA",
            Text = existingAddress?.Province ?? "",
            Location = new Point(24, yPos),
            Size = new Size(halfWidth, 52)
        };

        _countryInput = new StyledTextBox
        {
            Label = "PAÍS",
            Text = existingAddress?.Country ?? "",
            Location = new Point(24 + halfWidth + 16, yPos),
            Size = new Size(halfWidth, 52)
        };

        ContentPanel.Controls.AddRange(new Control[]
        {
            titleLabel, _labelInput, _street1Input, _street2Input,
            _postalCodeInput, _cityInput, _provinceInput, _countryInput
        });

        if (existingAddress != null)
        {
            _address = existingAddress;
        }
    }

    protected override bool ValidateInput()
    {
        _address = new PhysicalAddress
        {
            Id = _address?.Id ?? Guid.NewGuid(),
            Label = string.IsNullOrWhiteSpace(_labelInput.Text) ? "Casa" : _labelInput.Text,
            Street1 = _street1Input.Text,
            Street2 = _street2Input.Text,
            PostalCode = _postalCodeInput.Text,
            City = _cityInput.Text,
            Province = _provinceInput.Text,
            Country = _countryInput.Text
        };

        return true;
    }
}


/// <summary>
/// Diálogo modal para añadir o editar una nota.
/// </summary>
public class NoteModal : BaseModal
{
    private readonly StyledTextBox _noteInput;
    private ContactNote? _note;

    public ContactNote? Result => _note;

    public NoteModal(ContactNote? existingNote = null)
    {
        Text = existingNote == null ? "AÑADIR NOTA" : "EDITAR NOTA";
        SetContentSize(320, 200);

        // Title
        var titleLabel = new Label
        {
            Text = Text,
            Font = new Font("Segoe UI Semibold", 11f),
            ForeColor = ThemeManager.CurrentTheme.DarkText,
            AutoSize = true,
            Location = new Point(24, 24)
        };

        // Note input (multiline)
        _noteInput = new StyledTextBox
        {
            Text = existingNote?.Content ?? "",
            Multiline = true,
            Location = new Point(24, 60),
            Size = new Size(272, 80)
        };

        ContentPanel.Controls.Add(titleLabel);
        ContentPanel.Controls.Add(_noteInput);

        if (existingNote != null)
        {
            _note = existingNote;
        }
    }

    protected override bool ValidateInput()
    {
        _note = new ContactNote
        {
            Id = _note?.Id ?? Guid.NewGuid(),
            Content = _noteInput.Text,
            CreatedAt = _note?.CreatedAt ?? DateTime.Now
        };

        return true;
    }
}

/// <summary>
/// Diálogo modal para añadir la pronunciación del nombre.
/// </summary>
public class PronunciationModal : BaseModal
{
    private readonly StyledTextBox _pronunciationInput;
    private string _pronunciation = string.Empty;

    public string Result => _pronunciation;

    public PronunciationModal(string? existingPronunciation = null)
    {
        Text = "AÑADIR PRONUNCIACIÓN DE NOMBRE";
        SetContentSize(320, 180);

        // Title
        var titleLabel = new Label
        {
            Text = Text,
            Font = new Font("Segoe UI Semibold", 10f),
            ForeColor = ThemeManager.CurrentTheme.DarkText,
            AutoSize = true,
            Location = new Point(24, 24)
        };

        // Pronunciation input
        _pronunciationInput = new StyledTextBox
        {
            Text = existingPronunciation ?? "",
            Placeholder = "Ej: AH-nah MAR-tee-nez",
            Location = new Point(24, 70),
            Size = new Size(272, 36)
        };

        ContentPanel.Controls.Add(titleLabel);
        ContentPanel.Controls.Add(_pronunciationInput);
    }

    protected override bool ValidateInput()
    {
        _pronunciation = _pronunciationInput.Text;
        return true;
    }
}

/// <summary>
/// Diálogo modal para añadir o editar enlaces a redes sociales.
/// </summary>
public class SocialMediaModal : BaseModal
{
    private readonly ComboBox _platformCombo;
    private readonly StyledTextBox _usernameInput;
    private SocialMedia? _socialMedia;

    public SocialMedia? Result => _socialMedia;

    private static readonly string[] Platforms = 
    {
        "Twitter/X", "Instagram", "Facebook", "LinkedIn", 
        "TikTok", "YouTube", "GitHub", "Otro"
    };

    public SocialMediaModal(SocialMedia? existing = null)
    {
        Text = existing == null ? "AÑADIR REDES SOCIALES" : "EDITAR RED SOCIAL";
        SetContentSize(320, 220);

        // Title
        var titleLabel = new Label
        {
            Text = Text,
            Font = new Font("Segoe UI Semibold", 11f),
            ForeColor = ThemeManager.CurrentTheme.DarkText,
            AutoSize = true,
            Location = new Point(24, 24)
        };

        // Platform label
        var platformLabel = new Label
        {
            Text = "PLATAFORMA",
            Font = new Font("Segoe UI", 8.5f),
            ForeColor = ThemeManager.CurrentTheme.LabelText,
            AutoSize = true,
            Location = new Point(24, 60)
        };

        // Platform combo
        _platformCombo = new ComboBox
        {
            DropDownStyle = ComboBoxStyle.DropDownList,
            Font = new Font("Segoe UI", 10f),
            Location = new Point(24, 78),
            Size = new Size(272, 30),
            FlatStyle = FlatStyle.Flat
        };
        _platformCombo.Items.AddRange(Platforms);
        _platformCombo.SelectedIndex = existing != null 
            ? Array.IndexOf(Platforms, existing.Platform) 
            : 0;
        if (_platformCombo.SelectedIndex < 0) _platformCombo.SelectedIndex = Platforms.Length - 1;

        // Username input
        _usernameInput = new StyledTextBox
        {
            Label = "USUARIO / URL",
            Text = existing?.Username ?? "",
            Placeholder = "@usuario o URL",
            Location = new Point(24, 120),
            Size = new Size(272, 52)
        };

        ContentPanel.Controls.Add(titleLabel);
        ContentPanel.Controls.Add(platformLabel);
        ContentPanel.Controls.Add(_platformCombo);
        ContentPanel.Controls.Add(_usernameInput);

        if (existing != null)
        {
            _socialMedia = existing;
        }
    }

    protected override bool ValidateInput()
    {
        if (string.IsNullOrWhiteSpace(_usernameInput.Text))
        {
            MessageBox.Show("Por favor, introduce un usuario o URL.", 
                "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            _usernameInput.Focus();
            return false;
        }

        _socialMedia = new SocialMedia
        {
            Id = _socialMedia?.Id ?? Guid.NewGuid(),
            Platform = Platforms[_platformCombo.SelectedIndex],
            Username = _usernameInput.Text,
            Url = _usernameInput.Text.StartsWith("http") ? _usernameInput.Text : ""
        };

        return true;
    }
}

/// <summary>
/// Diálogo modal para añadir campos personalizados.
/// </summary>
public class CustomFieldModal : BaseModal
{
    private readonly StyledTextBox _labelInput;
    private readonly StyledTextBox _valueInput;
    private string _fieldLabel = string.Empty;
    private string _fieldValue = string.Empty;

    public string FieldLabel => _fieldLabel;
    public string FieldValue => _fieldValue;

    public CustomFieldModal(string? existingLabel = null, string? existingValue = null)
    {
        Text = "AÑADIR NUEVO CAMPO";
        SetContentSize(320, 220);

        // Title
        var titleLabel = new Label
        {
            Text = Text,
            Font = new Font("Segoe UI Semibold", 11f),
            ForeColor = ThemeManager.CurrentTheme.DarkText,
            AutoSize = true,
            Location = new Point(24, 24)
        };

        // Label input
        _labelInput = new StyledTextBox
        {
            Label = "NOMBRE DEL CAMPO",
            Text = existingLabel ?? "",
            Placeholder = "Ej: Cumpleaños",
            Location = new Point(24, 60),
            Size = new Size(272, 52)
        };

        // Value input
        _valueInput = new StyledTextBox
        {
            Label = "VALOR",
            Text = existingValue ?? "",
            Location = new Point(24, 120),
            Size = new Size(272, 52)
        };

        ContentPanel.Controls.Add(titleLabel);
        ContentPanel.Controls.Add(_labelInput);
        ContentPanel.Controls.Add(_valueInput);
    }

    protected override bool ValidateInput()
    {
        if (string.IsNullOrWhiteSpace(_labelInput.Text))
        {
            MessageBox.Show("Por favor, introduce un nombre para el campo.", 
                "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            _labelInput.Focus();
            return false;
        }

        _fieldLabel = _labelInput.Text;
        _fieldValue = _valueInput.Text;

        return true;
    }
}

/// <summary>
/// Diálogo de confirmación para eliminar un contacto.
/// </summary>
public class DeleteConfirmationModal : BaseModal
{
    private bool _confirmed;

    public bool Confirmed => _confirmed;

    public DeleteConfirmationModal(string contactName)
    {
        Text = "ELIMINAR CONTACTO";
        SetContentSize(320, 160);

        ConfirmButton.Style = StyledButton.ButtonStyle.Danger;
        ConfirmButton.Text = "CONFIRMAR";

        // Warning icon y mensaje
        var messageLabel = new Label
        {
            Text = $"¿ELIMINAR ESTE CONTACTO?",
            Font = new Font("Segoe UI Semibold", 11f),
            ForeColor = ThemeManager.CurrentTheme.AccentRed,
            AutoSize = true,
            Location = new Point(24, 40),
            TextAlign = ContentAlignment.MiddleCenter
        };

        var detailLabel = new Label
        {
            Text = $"Se eliminará \"{contactName}\" permanentemente.",
            Font = new Font("Segoe UI", 9.5f),
            ForeColor = ThemeManager.CurrentTheme.DarkText,
            AutoSize = true,
            Location = new Point(24, 70)
        };

        ContentPanel.Controls.Add(messageLabel);
        ContentPanel.Controls.Add(detailLabel);
    }

    protected override void OnConfirmClick(object? sender, EventArgs e)
    {
        _confirmed = true;
        base.OnConfirmClick(sender, e);
    }
}
