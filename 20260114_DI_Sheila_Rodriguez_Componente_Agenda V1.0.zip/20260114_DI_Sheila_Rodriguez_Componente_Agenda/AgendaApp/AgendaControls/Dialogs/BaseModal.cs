﻿using AgendaControls.Controls;
using AgendaControls.Themes;

namespace AgendaControls.Dialogs;

public abstract class BaseModal : Form
{
    protected Panel ContentPanel { get; private set; }
    protected Panel ButtonPanel { get; private set; }
    protected StyledButton ConfirmButton { get; private set; }
    protected StyledButton CancelButton { get; private set; }

    private bool _result;

    protected BaseModal()
    {
        // -------- FORM --------
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterParent;
        ShowInTaskbar = false;
        MaximizeBox = false;
        MinimizeBox = false;
        KeyPreview = true;
        AutoScaleMode = AutoScaleMode.None;

        // IMPORTANTE
        BackColor = ThemeManager.CurrentTheme.ModalBackground;

        // -------- CONTENT PANEL --------
        ContentPanel = new Panel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(20),
            BackColor = ThemeManager.CurrentTheme.ModalBackground
        };

        // -------- BUTTON PANEL --------
        ButtonPanel = new Panel
        {
            Dock = DockStyle.Bottom,
            Height = 60,
            Padding = new Padding(20, 10, 20, 15),
            BackColor = ThemeManager.CurrentTheme.ModalBackground
        };

        // -------- BUTTONS --------
        ConfirmButton = new StyledButton
        {
            Text = "CONFIRMAR",
            Style = StyledButton.ButtonStyle.Primary,
            Size = new Size(110, 35)
        };
        ConfirmButton.Click += OnConfirmClick;

        CancelButton = new StyledButton
        {
            Text = "CANCELAR",
            Style = StyledButton.ButtonStyle.Secondary,
            Size = new Size(110, 35)
        };
        CancelButton.Click += OnCancelClick;

        ButtonPanel.Controls.Add(ConfirmButton);
        ButtonPanel.Controls.Add(CancelButton);

        Controls.Add(ContentPanel);
        Controls.Add(ButtonPanel);

        // Escape
        KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Escape)
                OnCancelClick(this, EventArgs.Empty);
        };

        ThemeManager.ThemeChanged += (_, _) => ApplyTheme();
    }

    // evita el fondo blanco del sistema
    protected override void OnPaintBackground(PaintEventArgs e)
    {
        using var brush = new SolidBrush(ThemeManager.CurrentTheme.ModalBackground);
        e.Graphics.FillRectangle(brush, ClientRectangle);
    }

    protected override void OnShown(EventArgs e)
    {
        base.OnShown(e);
        ApplyTheme();
        PositionButtons();
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        PositionButtons();
    }

    // -------- THEME --------
    protected virtual void ApplyTheme()
    {
        BackColor = ThemeManager.CurrentTheme.ModalBackground;
        ContentPanel.BackColor = ThemeManager.CurrentTheme.ModalBackground;
        ButtonPanel.BackColor = ThemeManager.CurrentTheme.ModalBackground;

        ApplyThemeRecursive(this);
        Invalidate(true);
    }

    // APLICA FONDO A CONTROLES TRANSPARENTES
    private void ApplyThemeRecursive(Control parent)
    {
        foreach (Control c in parent.Controls)
        {
            if (c.BackColor == Color.Transparent)
                c.BackColor = ThemeManager.CurrentTheme.ModalBackground;

            ApplyThemeRecursive(c);
        }
    }

    // -------- BUTTONS --------
    private void PositionButtons()
    {
        var spacing = 10; // espacio entre botones
        var totalWidth = ConfirmButton.Width + spacing + CancelButton.Width;

        // Coordenada X inicial para centrar los botones
        var startX = (ButtonPanel.Width - totalWidth) / 2;

        // Coordenada Y centrada verticalmente
        var y = (ButtonPanel.Height - ConfirmButton.Height) / 2;

        ConfirmButton.Location = new Point(startX, y);
        CancelButton.Location = new Point(startX + ConfirmButton.Width + spacing, y);
    }


    protected virtual void OnConfirmClick(object? sender, EventArgs e)
    {
        if (ValidateInput())
        {
            _result = true;
            DialogResult = DialogResult.OK;
            Close();
        }
    }

    protected virtual void OnCancelClick(object? sender, EventArgs e)
    {
        _result = false;
        DialogResult = DialogResult.Cancel;
        Close();
    }

    protected virtual bool ValidateInput() => true;

    public new bool ShowDialog()
    {
        base.ShowDialog();
        return _result;
    }

    protected void SetContentSize(int width, int height)
    {
        ClientSize = new Size(width, height + ButtonPanel.Height);
    }
}
