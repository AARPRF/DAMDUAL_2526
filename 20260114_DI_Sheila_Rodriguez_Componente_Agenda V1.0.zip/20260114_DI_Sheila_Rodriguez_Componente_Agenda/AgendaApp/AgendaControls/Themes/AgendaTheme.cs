namespace AgendaControls.Themes;

/// <summary>
/// Defines the color theme for agenda controls.
/// </summary>
public class AgendaTheme
{
    // Colores de fondo
    public Color PrimaryBackground { get; set; } = Color.FromArgb(30, 35, 45);
    public Color SecondaryBackground { get; set; } = Color.FromArgb(45, 52, 65);
    public Color CardBackground { get; set; } = Color.FromArgb(55, 65, 80);
    public Color CardBackgroundHover { get; set; } = Color.FromArgb(65, 75, 90);
    public Color ModalBackground { get; set; } = Color.FromArgb(240, 245, 250);
    public Color ModalOverlay { get; set; } = Color.FromArgb(180, 0, 0, 0);

    // Colores de texto
    public Color PrimaryText { get; set; } = Color.White;
    public Color SecondaryText { get; set; } = Color.FromArgb(180, 180, 190);
    public Color MutedText { get; set; } = Color.FromArgb(120, 130, 140);
    public Color DarkText { get; set; } = Color.FromArgb(40, 50, 60);
    public Color LabelText { get; set; } = Color.FromArgb(100, 110, 120);

    // Colores de acento
    public Color AccentBlue { get; set; } = Color.FromArgb(70, 130, 180);
    public Color AccentBlueDark { get; set; } = Color.FromArgb(50, 100, 150);
    public Color AccentRed { get; set; } = Color.FromArgb(200, 80, 80);
    public Color AccentRedDark { get; set; } = Color.FromArgb(180, 60, 60);
    public Color AccentGreen { get; set; } = Color.FromArgb(80, 180, 120);
    public Color AccentYellow { get; set; } = Color.FromArgb(220, 180, 80);

    // Colores de borde
    public Color BorderLight { get; set; } = Color.FromArgb(80, 90, 100);
    public Color BorderDark { get; set; } = Color.FromArgb(200, 210, 220);
    public Color InputBorder { get; set; } = Color.FromArgb(180, 190, 200);
    public Color InputBorderFocused { get; set; } = Color.FromArgb(70, 130, 180);

    // COlores de avatar
    public Color AvatarBackground { get; set; } = Color.FromArgb(100, 120, 140);
    public Color AvatarText { get; set; } = Color.White;

    // Colores de pesta�a
    public Color TabBackground { get; set; } = Color.FromArgb(40, 48, 60);
    public Color TabActiveBackground { get; set; } = Color.FromArgb(70, 130, 180);
    public Color TabText { get; set; } = Color.FromArgb(150, 160, 170);
    public Color TabActiveText { get; set; } = Color.White;

    // Colores de scroll
    public Color ScrollbarTrack { get; set; } = Color.FromArgb(40, 48, 60);
    public Color ScrollbarThumb { get; set; } = Color.FromArgb(80, 90, 105);
    public Color ScrollbarThumbHover { get; set; } = Color.FromArgb(100, 110, 125);

    /// <summary>
    /// Tema oscuro para la app.
    /// </summary>
    public static AgendaTheme Dark => new();

    /// <summary>
    /// Tema claro para la app.
    /// </summary>
    public static AgendaTheme Light => new()
    {
        PrimaryBackground = Color.FromArgb(245, 248, 252),
        SecondaryBackground = Color.FromArgb(235, 240, 248),
        CardBackground = Color.White,
        CardBackgroundHover = Color.FromArgb(248, 250, 255),
        ModalBackground = Color.White,
        ModalOverlay = Color.FromArgb(150, 0, 0, 0),

        PrimaryText = Color.FromArgb(30, 40, 50),
        SecondaryText = Color.FromArgb(80, 90, 100),
        MutedText = Color.FromArgb(140, 150, 160),
        DarkText = Color.FromArgb(40, 50, 60),
        LabelText = Color.FromArgb(100, 110, 120),

        BorderLight = Color.FromArgb(220, 225, 235),
        BorderDark = Color.FromArgb(200, 210, 220),

        TabBackground = Color.FromArgb(230, 235, 245),
        TabActiveBackground = Color.FromArgb(70, 130, 180),
        TabText = Color.FromArgb(100, 110, 120),
        TabActiveText = Color.White,

        ScrollbarTrack = Color.FromArgb(240, 242, 248),
        ScrollbarThumb = Color.FromArgb(200, 208, 220),
        ScrollbarThumbHover = Color.FromArgb(180, 188, 200)
    };
}

/// <summary>
/// Permite controlar el tema a mostrar.
/// </summary>
public static class ThemeManager
{
    private static AgendaTheme _currentTheme = AgendaTheme.Dark;

    public static event EventHandler? ThemeChanged;

    public static AgendaTheme CurrentTheme
    {
        get => _currentTheme;
        set
        {
            _currentTheme = value;
            ThemeChanged?.Invoke(null, EventArgs.Empty);
        }
    }

    public static void ApplyDarkTheme() => CurrentTheme = AgendaTheme.Dark;
    public static void ApplyLightTheme() => CurrentTheme = AgendaTheme.Light;
}
