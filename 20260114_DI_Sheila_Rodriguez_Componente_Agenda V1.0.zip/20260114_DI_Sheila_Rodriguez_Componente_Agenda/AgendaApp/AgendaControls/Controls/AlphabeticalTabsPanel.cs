﻿using AgendaControls.Themes;

namespace AgendaControls.Controls;

public class AlphabeticalTabsPanel : UserControl
{
    private const char FavoritesChar = '★';

    private char _selectedLetter = 'A';
    private readonly Dictionary<char, Label> _letterLabels = new();
    private readonly HashSet<char> _activeLetters = new();
    private readonly Panel _innerPanel;

    public event EventHandler<char>? LetterSelected;

    public char SelectedLetter
    {
        get => _selectedLetter;
        set
        {
            if (_selectedLetter == value)
                return;

            _selectedLetter = value;
            UpdateButtonStates();
            LetterSelected?.Invoke(this, value);
        }
    }

    public AlphabeticalTabsPanel()
    {
        DoubleBuffered = true;
        Width = 28;
        BackColor = ThemeManager.CurrentTheme.TabBackground;

        _innerPanel = new Panel
        {
            Dock = DockStyle.Fill,
            AutoScroll = true,
            BackColor = Color.Transparent
        };

        Controls.Add(_innerPanel);
        CreateLetterLabels();

        ThemeManager.ThemeChanged += (_, _) => ApplyTheme();
    }

    public void SetActiveLetters(IEnumerable<char> letters)
    {
        _activeLetters.Clear();
        foreach (var l in letters)
            _activeLetters.Add(char.ToUpper(l));

        UpdateButtonStates();
    }

    private void CreateLetterLabels()
    {
        var letters = $"{FavoritesChar}ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        var y = 2;

        foreach (var letter in letters)
        {
            var label = new Label
            {
                Text = letter.ToString(),
                Size = new Size(24, 20),
                Location = new Point(2, y),
                Font = new Font("Segoe UI Semibold", 8f),
                TextAlign = ContentAlignment.MiddleCenter,
                Cursor = Cursors.Hand,
                Tag = letter,
                BackColor = Color.Transparent
            };

            label.Click += (_, _) => SelectedLetter = letter;

            _letterLabels[letter] = label;
            _innerPanel.Controls.Add(label);

            y += 21;
        }

        UpdateButtonStates();
    }

    private void UpdateButtonStates()
    {
        foreach (var (letter, label) in _letterLabels)
        {
            var selected = letter == _selectedLetter;
            var active = _activeLetters.Contains(letter);

            if (selected)
            {
                label.BackColor = ThemeManager.CurrentTheme.TabActiveBackground;
                label.ForeColor = ThemeManager.CurrentTheme.TabActiveText;
            }
            else if (active)
            {
                label.BackColor = Color.Transparent;
                label.ForeColor = letter == FavoritesChar
                    ? ThemeManager.CurrentTheme.AccentBlue
                    : ThemeManager.CurrentTheme.PrimaryText;
            }
            else
            {
                label.BackColor = Color.Transparent;
                label.ForeColor = ThemeManager.CurrentTheme.TabText;
            }
        }
    }

    private void ApplyTheme()
    {
        BackColor = ThemeManager.CurrentTheme.TabBackground;
        UpdateButtonStates();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        using var pen = new Pen(ThemeManager.CurrentTheme.BorderLight);
        e.Graphics.DrawLine(pen, Width - 1, 0, Width - 1, Height);
    }
}
