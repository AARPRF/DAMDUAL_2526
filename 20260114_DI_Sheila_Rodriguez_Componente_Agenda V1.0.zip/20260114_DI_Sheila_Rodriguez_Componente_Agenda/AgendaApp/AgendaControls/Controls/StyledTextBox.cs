using AgendaControls.Themes;

namespace AgendaControls.Controls;


public class StyledTextBox : UserControl
{
    private readonly TextBox _innerTextBox;
    private readonly Label _labelControl;
    private bool _isFocused;
    private string _label = string.Empty;
    private string _placeholder = string.Empty;

    public event EventHandler? TextChanged;

    public string Label
    {
        get => _label;
        set
        {
            _label = value;
            _labelControl.Text = value;
            _labelControl.Visible = !string.IsNullOrEmpty(value);
            UpdateLayout();
        }
    }

    public string Placeholder
    {
        get => _placeholder;
        set
        {
            _placeholder = value;
            UpdatePlaceholder();
        }
    }

    public override string Text
    {
        get => _innerTextBox.Text == _placeholder ? string.Empty : _innerTextBox.Text;
        set
        {
            _innerTextBox.Text = value;
            UpdatePlaceholder();
        }
    }

    public bool ReadOnly
    {
        get => _innerTextBox.ReadOnly;
        set => _innerTextBox.ReadOnly = value;
    }

    public bool Multiline
    {
        get => _innerTextBox.Multiline;
        set
        {
            _innerTextBox.Multiline = value;
            if (value)
            {
                _innerTextBox.ScrollBars = ScrollBars.Vertical;
                Height = 80;
            }
        }
    }

    public StyledTextBox()
    {
        // Inicializar label
        _labelControl = new Label
        {
            AutoSize = true,
            Font = new Font("Segoe UI", 8.5f),
            ForeColor = ThemeManager.CurrentTheme.LabelText,
            Location = new Point(0, 0),
            Visible = false
        };

        // Inicializar inner textbox
        _innerTextBox = new TextBox
        {
            BorderStyle = BorderStyle.None,
            Font = new Font("Segoe UI", 10f),
            BackColor = Color.White,
            ForeColor = ThemeManager.CurrentTheme.DarkText,
            Location = new Point(10, 8),
            Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
        };

        Controls.Add(_labelControl);
        Controls.Add(_innerTextBox);

        // Set default size
        Size = new Size(200, 36);
        Padding = new Padding(1);

        // Conectar eventos
        _innerTextBox.GotFocus += InnerTextBox_GotFocus;
        _innerTextBox.LostFocus += InnerTextBox_LostFocus;
        _innerTextBox.TextChanged += InnerTextBox_TextChanged;

        SetStyle(ControlStyles.AllPaintingInWmPaint |
                 ControlStyles.UserPaint |
                 ControlStyles.DoubleBuffer |
                 ControlStyles.ResizeRedraw, true);

        UpdateLayout();
    }

    private void UpdateLayout()
    {
        var yOffset = 0;
        if (_labelControl.Visible)
        {
            _labelControl.Location = new Point(2, 0);
            yOffset = _labelControl.Height + 4;
        }

        _innerTextBox.Location = new Point(10, yOffset + 8);
        _innerTextBox.Width = Width - 20;

        if (_labelControl.Visible)
        {
            Height = yOffset + 36;
        }
    }

    private void UpdatePlaceholder()
    {
        if (string.IsNullOrEmpty(_innerTextBox.Text) && !_isFocused && !string.IsNullOrEmpty(_placeholder))
        {
            _innerTextBox.Text = _placeholder;
            _innerTextBox.ForeColor = ThemeManager.CurrentTheme.MutedText;
        }
        else if (_innerTextBox.Text != _placeholder)
        {
            _innerTextBox.ForeColor = ThemeManager.CurrentTheme.DarkText;
        }
    }

    private void InnerTextBox_GotFocus(object? sender, EventArgs e)
    {
        _isFocused = true;
        if (_innerTextBox.Text == _placeholder)
        {
            _innerTextBox.Text = string.Empty;
            _innerTextBox.ForeColor = ThemeManager.CurrentTheme.DarkText;
        }
        Invalidate();
    }

    private void InnerTextBox_LostFocus(object? sender, EventArgs e)
    {
        _isFocused = false;
        UpdatePlaceholder();
        Invalidate();
    }

    private void InnerTextBox_TextChanged(object? sender, EventArgs e)
    {
        TextChanged?.Invoke(this, e);
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        UpdateLayout();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        var g = e.Graphics;
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

        // Calcular input area
        var inputY = _labelControl.Visible ? _labelControl.Height + 4 : 0;
        var inputRect = new Rectangle(0, inputY, Width - 1, Height - inputY - 1);

        // Dibujar el fondo
        var radius = 6;
        using var path = CreateRoundedRectangle(inputRect, radius);
        using var bgBrush = new SolidBrush(Color.White);
        g.FillPath(bgBrush, path);

        // Dibujar borde
        var borderColor = _isFocused
            ? ThemeManager.CurrentTheme.InputBorderFocused
            : ThemeManager.CurrentTheme.InputBorder;
        using var pen = new Pen(borderColor, _isFocused ? 2 : 1);
        g.DrawPath(pen, path);
    }

    private static System.Drawing.Drawing2D.GraphicsPath CreateRoundedRectangle(Rectangle rect, int radius)
    {
        var path = new System.Drawing.Drawing2D.GraphicsPath();
        var diameter = radius * 2;

        path.AddArc(rect.X, rect.Y, diameter, diameter, 180, 90);
        path.AddArc(rect.Right - diameter, rect.Y, diameter, diameter, 270, 90);
        path.AddArc(rect.Right - diameter, rect.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(rect.X, rect.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();

        return path;
    }

    public new void Focus()
    {
        _innerTextBox.Focus();
    }

    public void SelectAll()
    {
        _innerTextBox.SelectAll();
    }
}
