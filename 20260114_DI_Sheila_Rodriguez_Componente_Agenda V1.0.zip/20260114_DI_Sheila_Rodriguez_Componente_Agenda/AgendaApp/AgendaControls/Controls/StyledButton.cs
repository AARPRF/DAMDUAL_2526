using AgendaControls.Themes;

namespace AgendaControls.Controls;


public class StyledButton : Button
{
    private bool _isHovered;
    private bool _isPressed;
    private ButtonStyle _buttonStyle = ButtonStyle.Primary;

    public enum ButtonStyle
    {
        Primary,
        Secondary,
        Danger,
        Link
    }

    public ButtonStyle Style
    {
        get => _buttonStyle;
        set
        {
            _buttonStyle = value;
            Invalidate();
        }
    }

    public StyledButton()
    {
        FlatStyle = FlatStyle.Flat;
        FlatAppearance.BorderSize = 0;
        Cursor = Cursors.Hand;
        Font = new Font("Segoe UI Semibold", 9f);
        Size = new Size(100, 32);
        TextAlign = ContentAlignment.MiddleCenter;

        SetStyle(ControlStyles.AllPaintingInWmPaint |
                 ControlStyles.UserPaint |
                 ControlStyles.OptimizedDoubleBuffer, true);
    }

    protected override void OnMouseEnter(EventArgs e)
    {
        _isHovered = true;
        Invalidate();
        base.OnMouseEnter(e);
    }

    protected override void OnMouseLeave(EventArgs e)
    {
        _isHovered = false;
        _isPressed = false;
        Invalidate();
        base.OnMouseLeave(e);
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        _isPressed = true;
        Invalidate();
        base.OnMouseDown(e);
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        _isPressed = false;
        Invalidate();
        base.OnMouseUp(e);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None; // nada de anti-aliasing para esquinas

        var (bgColor, textColor) = GetColors();

        // Dibujar background simple (rect�ngulo plano)
        using var brush = new SolidBrush(bgColor);
        g.FillRectangle(brush, ClientRectangle);

        // Dibujar borde solo para secondary si quieres
        if (_buttonStyle == ButtonStyle.Secondary)
        {
            using var pen = new Pen(ThemeManager.CurrentTheme.BorderDark, 1);
            g.DrawRectangle(pen, 0, 0, Width - 1, Height - 1);
        }

        // Dibujar texto centrado
        TextRenderer.DrawText(
            g,
            Text,
            Font,
            ClientRectangle,
            textColor,
            TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter
        );
    }

    private (Color bg, Color text) GetColors()
    {
        var theme = ThemeManager.CurrentTheme;

        return _buttonStyle switch
        {
            ButtonStyle.Primary => _isPressed
                ? (theme.AccentBlueDark, Color.White)
                : _isHovered
                    ? (Color.FromArgb(
                        Math.Min(theme.AccentBlue.R + 15, 255),
                        Math.Min(theme.AccentBlue.G + 15, 255),
                        Math.Min(theme.AccentBlue.B + 15, 255)), Color.White)
                    : (theme.AccentBlue, Color.White),

            ButtonStyle.Secondary => _isPressed
                ? (Color.FromArgb(230, 235, 240), theme.DarkText)
                : _isHovered
                    ? (Color.FromArgb(245, 248, 252), theme.DarkText)
                    : (Color.White, theme.DarkText),

            ButtonStyle.Danger => _isPressed
                ? (theme.AccentRedDark, Color.White)
                : _isHovered
                    ? (Color.FromArgb(
                        Math.Min(theme.AccentRed.R + 15, 255),
                        Math.Min(theme.AccentRed.G + 15, 255),
                        Math.Min(theme.AccentRed.B + 15, 255)), Color.White)
                    : (theme.AccentRed, Color.White),

            ButtonStyle.Link => _isPressed
                ? (Color.Transparent, theme.AccentBlueDark)
                : _isHovered
                    ? (Color.Transparent, theme.AccentBlue)
                    : (Color.Transparent, theme.AccentBlue),

            _ => (theme.AccentBlue, Color.White)
        };
    }
}
