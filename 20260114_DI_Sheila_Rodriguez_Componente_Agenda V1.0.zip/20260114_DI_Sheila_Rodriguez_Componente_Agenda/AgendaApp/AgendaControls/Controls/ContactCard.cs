using AgendaControls.Models;
using AgendaControls.Themes;
using AgendaControls.Events;

namespace AgendaControls.Controls;

/// <summary>
/// Tarjeta de contacto compacta que muestra informaci�n b�sica.
/// Al hacer clic en la tarjeta se abre el panel de detalle del contacto.
/// </summary>
public class ContactCard : UserControl
{
    private Contact? _contact;
    private bool _isHovered;
    private bool _isSelected;

    // UI Elements
    private readonly PictureBox _avatarBox;
    private readonly Label _nameLabel;
    private readonly Label _phoneLabel;

    public event EventHandler<ContactEventArgs>? ContactClicked;
    public event EventHandler<ContactEventArgs>? ContactDoubleClicked;

    public Contact? Contact
    {
        get => _contact;
        set
        {
            _contact = value;
            UpdateDisplay();
        }
    }

    public bool IsSelected
    {
        get => _isSelected;
        set
        {
            _isSelected = value;
            Invalidate();
        }
    }

    public ContactCard()
    {
        // Inicializa control properties
        Size = new Size(220, 50);
        Cursor = Cursors.Hand;
        DoubleBuffered = true;
        Padding = new Padding(8);

        // Crear avatar
        _avatarBox = new PictureBox
        {
            Size = new Size(36, 36),
            Location = new Point(8, 7),
            SizeMode = PictureBoxSizeMode.Zoom,
            BackColor = Color.Transparent
        };

        // Crear name label
        _nameLabel = new Label
        {
            AutoSize = false,
            Size = new Size(140, 18),
            Location = new Point(52, 8),
            Font = new Font("Segoe UI Semibold", 9.5f),
            ForeColor = ThemeManager.CurrentTheme.PrimaryText,
            BackColor = Color.Transparent,
            TextAlign = ContentAlignment.MiddleLeft
        };

        // Crear phone label
        _phoneLabel = new Label
        {
            AutoSize = false,
            Size = new Size(140, 16),
            Location = new Point(52, 26),
            Font = new Font("Segoe UI", 8.5f),
            ForeColor = ThemeManager.CurrentTheme.SecondaryText,
            BackColor = Color.Transparent,
            TextAlign = ContentAlignment.MiddleLeft
        };

        // Add controls
        Controls.Add(_avatarBox);
        Controls.Add(_nameLabel);
        Controls.Add(_phoneLabel);

        // Conectar eventos
        MouseEnter += OnMouseEnterHandler;
        MouseLeave += OnMouseLeaveHandler;
        Click += OnClickHandler;
        DoubleClick += OnDoubleClickHandler;

        foreach (Control control in Controls)
        {
            control.MouseEnter += (s, e) => OnMouseEnterHandler(s, e);
            control.MouseLeave += (s, e) => OnMouseLeaveHandler(s, e);
            control.Click += (s, e) => OnClickHandler(s, e);
            control.DoubleClick += (s, e) => OnDoubleClickHandler(s, e);
            control.Cursor = Cursors.Hand;
        }

        // Guardar cambios de tema
        ThemeManager.ThemeChanged += (s, e) => ApplyTheme();
        ApplyTheme();
    }

    private void UpdateDisplay()
    {
        if (_contact == null)
        {
            _nameLabel.Text = "";
            _phoneLabel.Text = "";
            _avatarBox.Image = null;
            return;
        }

        _nameLabel.Text = _contact.FullName;
        _phoneLabel.Text = _contact.PrimaryPhone ?? "";

        // Update avatar
        UpdateAvatar();
    }

    private void UpdateAvatar()
    {
        if (_contact?.ProfileImage != null && _contact.ProfileImage.Length > 0)
        {
            try
            {
                using var ms = new MemoryStream(_contact.ProfileImage);
                _avatarBox.Image = Image.FromStream(ms);
            }
            catch
            {
                CreateInitialsAvatar();
            }
        }
        else
        {
            CreateInitialsAvatar();
        }
    }

    private void CreateInitialsAvatar()
    {
        var size = _avatarBox.Size;
        var bitmap = new Bitmap(size.Width, size.Height);
        using var g = Graphics.FromImage(bitmap);
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        
        // Dibujar fondo circular
        using var brush = new SolidBrush(ThemeManager.CurrentTheme.AvatarBackground);
        g.FillEllipse(brush, 0, 0, size.Width - 1, size.Height - 1);

        // Dibujar iniciales
        var initials = _contact?.Initials ?? "?";
        using var font = new Font("Segoe UI Semibold", 11f);
        using var textBrush = new SolidBrush(ThemeManager.CurrentTheme.AvatarText);
        var textSize = g.MeasureString(initials, font);
        var x = (size.Width - textSize.Width) / 2;
        var y = (size.Height - textSize.Height) / 2;
        g.DrawString(initials, font, textBrush, x, y);

        _avatarBox.Image?.Dispose();
        _avatarBox.Image = bitmap;
    }

    private void ApplyTheme()
    {
        _nameLabel.ForeColor = ThemeManager.CurrentTheme.PrimaryText;
        _phoneLabel.ForeColor = ThemeManager.CurrentTheme.SecondaryText;
        UpdateAvatar();
        Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        var g = e.Graphics;
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

        // Determinar color de fondo
        Color bgColor;
        if (_isSelected)
            bgColor = ThemeManager.CurrentTheme.AccentBlue;
        else if (_isHovered)
            bgColor = ThemeManager.CurrentTheme.CardBackgroundHover;
        else
            bgColor = ThemeManager.CurrentTheme.CardBackground;

        // Dibujar fondo rectangular con bordes redondeados
        var rect = new Rectangle(0, 0, Width - 1, Height - 1);
        var radius = 8;
        using var path = CreateRoundedRectangle(rect, radius);
        using var brush = new SolidBrush(bgColor);
        g.FillPath(brush, path);

        // Dibujar borde
        using var pen = new Pen(ThemeManager.CurrentTheme.BorderLight, 1);
        g.DrawPath(pen, path);
    }

    private static System.Drawing.Drawing2D.GraphicsPath CreateRoundedRectangle(Rectangle rect, int radius)
    {
        var path = new System.Drawing.Drawing2D.GraphicsPath();
        var diameter = radius * 2;
        
        path.AddArc(rect.X, rect.Y, diameter, diameter, 180, 90);
        path.AddArc(rect.Right - diameter, rect.Y, diameter, diameter, 270, 90);
        path.AddArc(rect.Right - diameter, rect.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(rect.X, rect.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        
        return path;
    }

    private void OnMouseEnterHandler(object? sender, EventArgs e)
    {
        _isHovered = true;
        Invalidate();
    }

    private void OnMouseLeaveHandler(object? sender, EventArgs e)
    {
        // Comprobar si el rat�n sigue dentro de los l�mites del control
        var mousePos = PointToClient(MousePosition);
        if (!ClientRectangle.Contains(mousePos))
        {
            _isHovered = false;
            Invalidate();
        }
    }

    private void OnClickHandler(object? sender, EventArgs e)
    {
        if (_contact != null)
        {
            ContactClicked?.Invoke(this, new ContactEventArgs(_contact));
        }
    }

    private void OnDoubleClickHandler(object? sender, EventArgs e)
    {
        if (_contact != null)
        {
            ContactDoubleClicked?.Invoke(this, new ContactEventArgs(_contact));
        }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _avatarBox.Image?.Dispose();
        }
        base.Dispose(disposing);
    }
}
