using AgendaControls.Models;
using AgendaControls.Themes;
using AgendaControls.Events;
using AgendaControls.Dialogs;

namespace AgendaControls.Controls;

/// <summary>
/// Panel de detalle de contacto expandido que muestra la información completa
/// del contacto y permite su edición.
/// </summary>
public class ContactDetailPanel : UserControl
{
    private Contact? _contact;
    private Contact? _originalContact;

    // Header controls
    private readonly Panel _headerPanel;
    private readonly PictureBox _avatarBox;
    private readonly Label _nameLabel;
    private readonly Label _organizationLabel;
    private readonly Button _backButton;
    private readonly Button _favoriteButton;

    // Content panel (scrollable)
    private readonly Panel _contentPanel;

    // Delete button
    private readonly Button _deleteButton;

    // Events
    public event EventHandler? BackRequested;
    public event EventHandler<ContactModifiedEventArgs>? ContactModified;
    public event EventHandler<ContactDeleteEventArgs>? ContactDeleting;

    public Contact? Contact
    {
        get => _contact;
        set
        {
            _contact = value?.Clone();
            _originalContact = value;
            UpdateDisplay();
        }
    }

    public ContactDetailPanel()
    {
        DoubleBuffered = true;
        AutoScroll = false;
        BackColor = ThemeManager.CurrentTheme.PrimaryBackground;

        // Aumentada la altura para espaciado adecuado
        _headerPanel = new Panel
        {
            Dock = DockStyle.Top,
            Height = 220,
            BackColor = ThemeManager.CurrentTheme.PrimaryBackground,
            Padding = new Padding(15)
        };

        // Ajustado tamaño y posición
        _backButton = new Button
        {
            Text = "←",
            FlatStyle = FlatStyle.Flat,
            Size = new Size(50, 40),
            Location = new Point(5, 5),
            Font = new Font("Segoe UI", 16f),
            ForeColor = ThemeManager.CurrentTheme.AccentBlue,
            BackColor = Color.Transparent,
            Cursor = Cursors.Hand
        };
        _backButton.FlatAppearance.BorderSize = 0;
        _backButton.Click += (s, e) => BackRequested?.Invoke(this, EventArgs.Empty);

        // ajustado tamaño
        _favoriteButton = new Button
        {
            Text = "☆",
            FlatStyle = FlatStyle.Flat,
            Size = new Size(50, 40),
            Location = new Point(10, 5),
            Font = new Font("Segoe UI", 18f),
            ForeColor = ThemeManager.CurrentTheme.SecondaryText,
            BackColor = Color.Transparent,
            Cursor = Cursors.Hand,
            Anchor = AnchorStyles.Top | AnchorStyles.Right
        };
        _favoriteButton.FlatAppearance.BorderSize = 0;
        _favoriteButton.Click += ToggleFavorite;

        // Avatar
        _avatarBox = new PictureBox
        {
            Size = new Size(80, 80),
            SizeMode = PictureBoxSizeMode.Zoom,
            BackColor = Color.Transparent,
            Anchor = AnchorStyles.Top
        };

        // Nombre
        _nameLabel = new Label
        {
            Font = new Font("Segoe UI Semibold", 16f),
            ForeColor = ThemeManager.CurrentTheme.PrimaryText,
            TextAlign = ContentAlignment.MiddleCenter,
            AutoSize = false,
            Height = 30,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
        };

        // Organizacion
        _organizationLabel = new Label
        {
            Font = new Font("Segoe UI", 10f),
            ForeColor = ThemeManager.CurrentTheme.SecondaryText,
            TextAlign = ContentAlignment.MiddleCenter,
            AutoSize = false,
            Height = 22,
            Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
        };

        _headerPanel.Controls.Add(_backButton);
        _headerPanel.Controls.Add(_favoriteButton);
        _headerPanel.Controls.Add(_avatarBox);
        _headerPanel.Controls.Add(_nameLabel);
        _headerPanel.Controls.Add(_organizationLabel);

        // Content panel (scrollable)
        _contentPanel = new Panel
        {
            Dock = DockStyle.Fill,
            AutoScroll = true,
            BackColor = ThemeManager.CurrentTheme.PrimaryBackground,
            Padding = new Padding(20, 10, 20, 10)
        };

        // Delete button - fijado abajo
        _deleteButton = new Button
        {
            Text = "ELIMINAR CONTACTO",
            FlatStyle = FlatStyle.Flat,
            Height = 45,
            Dock = DockStyle.Bottom,
            Font = new Font("Segoe UI Semibold", 10f),
            ForeColor = Color.White,
            BackColor = ThemeManager.CurrentTheme.AccentRed,
            Cursor = Cursors.Hand
        };
        _deleteButton.FlatAppearance.BorderSize = 0;
        _deleteButton.Click += DeleteContact;

        // Añadir controles en el orden correcto
        Controls.Add(_contentPanel);
        Controls.Add(_deleteButton);
        Controls.Add(_headerPanel);

        // Permitir ajustar tamaño
        Resize += (s, e) => LayoutHeader();

        // Manejar el cambio de visibilidad para corregir el diseño inicial
        VisibleChanged += (s, e) => 
        {
            if (Visible)
            {
                BeginInvoke(new Action(() =>
                {
                    LayoutHeader();
                    RebuildContent();
                }));
            }
        };

        // Guardar cambios de tema
        ThemeManager.ThemeChanged += (s, e) => ApplyTheme();
    }

    private void LayoutHeader()
    {
        if (_headerPanel == null) return;

        var centerX = _headerPanel.Width / 2;

        _avatarBox.Location = new Point(centerX - 40, 55);
        _nameLabel.Location = new Point(20, 145);
        _nameLabel.Width = _headerPanel.Width - 40;
        _organizationLabel.Location = new Point(20, 175);
        _organizationLabel.Width = _headerPanel.Width - 40;
        _favoriteButton.Location = new Point(_headerPanel.Width - 55, 5);
    }

    private void UpdateDisplay()
    {
        if (_contact == null)
        {
            ClearDisplay();
            return;
        }

        _nameLabel.Text = _contact.FullName;
        _organizationLabel.Text = _contact.Organization;
        _organizationLabel.Visible = !string.IsNullOrEmpty(_contact.Organization);
        UpdateAvatar();
        UpdateFavoriteButton();
        LayoutHeader();
        RebuildContent();
    }

    private void ClearDisplay()
    {
        _nameLabel.Text = "";
        _organizationLabel.Text = "";
        _avatarBox.Image = null;
        _contentPanel.Controls.Clear();
    }

    private void RebuildContent()
    {
        _contentPanel.Controls.Clear();
        var yPos = 10;
        var contentWidth = _contentPanel.Width - 50;

        // Phone numbers
        foreach (var phone in _contact!.PhoneNumbers)
        {
            var phonePanel = CreateInfoRow("📱", phone.Number, phone.Label, contentWidth);
            phonePanel.Location = new Point(10, yPos);
            _contentPanel.Controls.Add(phonePanel);
            yPos += phonePanel.Height + 5;
        }

        // Add phone button
        var addPhoneBtn = CreateAddButton("+ AÑADIR TELÉFONO", contentWidth);
        addPhoneBtn.Location = new Point(10, yPos);
        addPhoneBtn.Click += AddPhone;
        _contentPanel.Controls.Add(addPhoneBtn);
        yPos += addPhoneBtn.Height + 15;

        // Emails
        foreach (var email in _contact.Emails)
        {
            var emailPanel = CreateInfoRow("✉", email.Email, email.Label, contentWidth, true);
            emailPanel.Location = new Point(10, yPos);
            _contentPanel.Controls.Add(emailPanel);
            yPos += emailPanel.Height + 5;
        }

        // Add email button
        var addEmailBtn = CreateAddButton("+ AÑADIR E-MAIL", contentWidth);
        addEmailBtn.Location = new Point(10, yPos);
        addEmailBtn.Click += AddEmail;
        _contentPanel.Controls.Add(addEmailBtn);
        yPos += addEmailBtn.Height + 15;

        // Add info button
        var addInfoBtn = CreateAddButton("+ AÑADIR INFORMACIÓN", contentWidth);
        addInfoBtn.Location = new Point(10, yPos);
        addInfoBtn.Click += ShowAddInfoMenu;
        _contentPanel.Controls.Add(addInfoBtn);
        yPos += addInfoBtn.Height + 15;

        // Addresses
        if (_contact.Addresses.Any())
        {
            var addressTitle = CreateSectionTitle("DIRECCIONES");
            addressTitle.Location = new Point(10, yPos);
            _contentPanel.Controls.Add(addressTitle);
            yPos += addressTitle.Height + 5;

            foreach (var address in _contact.Addresses)
            {
                var addressPanel = CreateInfoRow("📍", address.FormattedAddress.Replace("\n", ", "), address.Label, contentWidth);
                addressPanel.Location = new Point(10, yPos);
                _contentPanel.Controls.Add(addressPanel);
                yPos += addressPanel.Height + 5;
            }
            yPos += 10;
        }

        // Social media
        if (_contact.SocialMediaLinks.Any())
        {
            var socialTitle = CreateSectionTitle("REDES SOCIALES");
            socialTitle.Location = new Point(10, yPos);
            _contentPanel.Controls.Add(socialTitle);
            yPos += socialTitle.Height + 5;

            foreach (var social in _contact.SocialMediaLinks)
            {
                var socialPanel = CreateInfoRow("🔗", social.Username, social.Platform, contentWidth, true);
                socialPanel.Location = new Point(10, yPos);
                _contentPanel.Controls.Add(socialPanel);
                yPos += socialPanel.Height + 5;
            }
            yPos += 10;
        }

        // Notas
        var notesTitle = CreateSectionTitle("📝 NOTAS:");
        notesTitle.Location = new Point(10, yPos);
        _contentPanel.Controls.Add(notesTitle);
        yPos += notesTitle.Height + 5;

        foreach (var note in _contact.Notes)
        {
            var notePanel = CreateNotePanel(note, contentWidth);
            notePanel.Location = new Point(10, yPos);
            _contentPanel.Controls.Add(notePanel);
            yPos += notePanel.Height + 5;
        }

        // Add note button
        var addNoteBtn = CreateAddButton("+ AÑADIR NOTA", contentWidth);
        addNoteBtn.Location = new Point(10, yPos);
        addNoteBtn.Click += AddNote;
        _contentPanel.Controls.Add(addNoteBtn);
        yPos += addNoteBtn.Height + 20;
    }

    private Panel CreateInfoRow(string icon, string text, string label, int width, bool isLink = false)
    {
        var panel = new Panel
        {
            Size = new Size(width, 45),
            BackColor = Color.Transparent
        };

        var iconLabel = new Label
        {
            Text = icon,
            Font = new Font("Segoe UI", 14f),
            Size = new Size(30, 30),
            Location = new Point(0, 8),
            ForeColor = ThemeManager.CurrentTheme.SecondaryText
        };

        var textLabel = new Label
        {
            Text = text,
            Font = new Font("Segoe UI", 10f),
            ForeColor = isLink ? ThemeManager.CurrentTheme.AccentBlue : ThemeManager.CurrentTheme.PrimaryText,
            AutoSize = true,
            Location = new Point(35, 5),
            MaximumSize = new Size(width - 50, 0),
            Cursor = isLink ? Cursors.Hand : Cursors.Default
        };

        var labelLabel = new Label
        {
            Text = label,
            Font = new Font("Segoe UI", 8.5f),
            ForeColor = ThemeManager.CurrentTheme.MutedText,
            AutoSize = true,
            Location = new Point(35, 25)
        };

        panel.Controls.Add(iconLabel);
        panel.Controls.Add(textLabel);
        panel.Controls.Add(labelLabel);

        return panel;
    }

    private Label CreateSectionTitle(string text)
    {
        return new Label
        {
            Text = text,
            Font = new Font("Segoe UI Semibold", 9f),
            ForeColor = ThemeManager.CurrentTheme.MutedText,
            AutoSize = true
        };
    }

    private Button CreateAddButton(string text, int width)
    {
        var btn = new Button
        {
            Text = text,
            FlatStyle = FlatStyle.Flat,
            Size = new Size(width, 30),
            Font = new Font("Segoe UI", 9f),
            ForeColor = ThemeManager.CurrentTheme.AccentBlue,
            BackColor = Color.Transparent,
            Cursor = Cursors.Hand,
            TextAlign = ContentAlignment.MiddleLeft
        };
        btn.FlatAppearance.BorderSize = 0;
        return btn;
    }

    private Panel CreateNotePanel(ContactNote note, int width)
    {
        var panel = new Panel
        {
            Size = new Size(width, 50),
            BackColor = Color.Transparent
        };

        var contentLabel = new Label
        {
            Text = note.Content,
            Font = new Font("Segoe UI", 9.5f),
            ForeColor = ThemeManager.CurrentTheme.PrimaryText,
            AutoSize = true,
            MaximumSize = new Size(width - 10, 0),
            Location = new Point(0, 0)
        };

        var dateLabel = new Label
        {
            Text = note.CreatedAt.ToString("dd/MM/yyyy HH:mm"),
            Font = new Font("Segoe UI", 8f),
            ForeColor = ThemeManager.CurrentTheme.MutedText,
            AutoSize = true,
            Location = new Point(0, contentLabel.PreferredHeight + 3)
        };

        panel.Controls.Add(contentLabel);
        panel.Controls.Add(dateLabel);
        panel.Height = contentLabel.PreferredHeight + dateLabel.PreferredHeight + 10;

        return panel;
    }

    private void UpdateAvatar()
    {
        var size = _avatarBox.Size;
        var bitmap = new Bitmap(size.Width, size.Height);
        using var g = Graphics.FromImage(bitmap);
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

        using var brush = new SolidBrush(ThemeManager.CurrentTheme.AvatarBackground);
        g.FillEllipse(brush, 0, 0, size.Width - 1, size.Height - 1);

        var initials = _contact?.Initials ?? "?";
        using var font = new Font("Segoe UI Semibold", 24f);
        using var textBrush = new SolidBrush(ThemeManager.CurrentTheme.AvatarText);
        var textSize = g.MeasureString(initials, font);
        var x = (size.Width - textSize.Width) / 2;
        var y = (size.Height - textSize.Height) / 2;
        g.DrawString(initials, font, textBrush, x, y);

        _avatarBox.Image?.Dispose();
        _avatarBox.Image = bitmap;
    }

    private void UpdateFavoriteButton()
    {
        _favoriteButton.Text = _contact?.IsFavorite == true ? "★" : "☆";
        _favoriteButton.ForeColor = _contact?.IsFavorite == true
            ? ThemeManager.CurrentTheme.AccentYellow
            : ThemeManager.CurrentTheme.SecondaryText;
    }

    private void ToggleFavorite(object? sender, EventArgs e)
    {
        if (_contact == null) return;
        _contact.IsFavorite = !_contact.IsFavorite;
        UpdateFavoriteButton();
        NotifyContactModified(ModificationType.Updated);
    }

    private void ApplyTheme()
    {
        BackColor = ThemeManager.CurrentTheme.PrimaryBackground;
        _headerPanel.BackColor = ThemeManager.CurrentTheme.PrimaryBackground;
        _contentPanel.BackColor = ThemeManager.CurrentTheme.PrimaryBackground;
        _nameLabel.ForeColor = ThemeManager.CurrentTheme.PrimaryText;
        _organizationLabel.ForeColor = ThemeManager.CurrentTheme.SecondaryText;
        _backButton.ForeColor = ThemeManager.CurrentTheme.AccentBlue;
        _deleteButton.BackColor = ThemeManager.CurrentTheme.AccentRed;
        UpdateAvatar();
        UpdateFavoriteButton();
        if (_contact != null) RebuildContent();
    }

    #region Add Methods

    private void AddPhone(object? sender, EventArgs e)
    {
        using var modal = new PhoneModal();
        if (modal.ShowDialog() && modal.Result != null)
        {
            _contact!.PhoneNumbers.Add(modal.Result);
            NotifyContactModified(ModificationType.FieldAdded);
            RebuildContent();
        }
    }

    private void AddEmail(object? sender, EventArgs e)
    {
        using var modal = new EmailModal();
        if (modal.ShowDialog() && modal.Result != null)
        {
            _contact!.Emails.Add(modal.Result);
            NotifyContactModified(ModificationType.FieldAdded);
            RebuildContent();
        }
    }

    private void ShowAddInfoMenu(object? sender, EventArgs e)
    {
        var menu = new ContextMenuStrip();
        menu.Items.Add("Añadir pronunciación de nombre", null, (s, args) => AddPronunciation());
        menu.Items.Add("Añadir dirección física", null, (s, args) => AddAddress());
        menu.Items.Add("Añadir redes sociales", null, (s, args) => AddSocialMedia());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Añadir nuevo campo", null, (s, args) => AddCustomField());

        if (sender is Button btn)
            menu.Show(btn, new Point(0, btn.Height));
    }

    private void AddPronunciation()
    {
        using var modal = new PronunciationModal(_contact?.NamePronunciation);
        if (modal.ShowDialog())
        {
            _contact!.NamePronunciation = modal.Result;
            NotifyContactModified(ModificationType.Updated);
        }
    }

    private void AddAddress()
    {
        using var modal = new AddressModal();
        if (modal.ShowDialog() && modal.Result != null)
        {
            _contact!.Addresses.Add(modal.Result);
            NotifyContactModified(ModificationType.FieldAdded);
            RebuildContent();
        }
    }

    private void AddSocialMedia()
    {
        using var modal = new SocialMediaModal();
        if (modal.ShowDialog() && modal.Result != null)
        {
            _contact!.SocialMediaLinks.Add(modal.Result);
            NotifyContactModified(ModificationType.FieldAdded);
            RebuildContent();
        }
    }

    private void AddCustomField()
    {
        using var modal = new CustomFieldModal();
        if (modal.ShowDialog())
        {
            _contact!.CustomFields[modal.FieldLabel] = modal.FieldValue;
            NotifyContactModified(ModificationType.FieldAdded);
            RebuildContent();
        }
    }

    private void AddNote(object? sender, EventArgs e)
    {
        using var modal = new NoteModal();
        if (modal.ShowDialog() && modal.Result != null)
        {
            _contact!.Notes.Add(modal.Result);
            NotifyContactModified(ModificationType.FieldAdded);
            RebuildContent();
        }
    }

    private void DeleteContact(object? sender, EventArgs e)
    {
        if (_contact == null) return;

        using var modal = new DeleteConfirmationModal(_contact.FullName);
        if (modal.ShowDialog() && modal.Confirmed)
        {
            var deleteArgs = new ContactDeleteEventArgs(_contact);
            ContactDeleting?.Invoke(this, deleteArgs);

            if (!deleteArgs.Cancel)
            {
                NotifyContactModified(ModificationType.Deleted);
                BackRequested?.Invoke(this, EventArgs.Empty);
            }
        }
    }

    #endregion

    private void NotifyContactModified(ModificationType type)
    {
        if (_contact != null && _originalContact != null)
        {
            ContactModified?.Invoke(this, new ContactModifiedEventArgs(
                _contact, _originalContact, type));
        }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _avatarBox.Image?.Dispose();
        }
        base.Dispose(disposing);
    }
}
