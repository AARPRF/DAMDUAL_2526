﻿using AgendaControls.Models;
using AgendaControls.Themes;
using AgendaControls.Events;

namespace AgendaControls.Controls;

public class AgendaControl : UserControl
{
    private const char FavoritesChar = '★';

    private readonly AlphabeticalTabsPanel _tabsPanel;
    private readonly Panel _listPanel;
    private readonly ContactDetailPanel _detailPanel;
    private readonly FlowLayoutPanel _contactsContainer;
    private readonly Label _emptyLabel;

    private List<Contact> _contacts = new();
    private Contact? _selectedContact;
    private bool _showingDetail;

    // EVENTS
    public event EventHandler<ContactEventArgs>? ContactSelected;
    public event EventHandler<ContactModifiedEventArgs>? ContactModified;
    public event EventHandler<ContactDeleteEventArgs>? ContactDeleting;
    public event EventHandler<ContactEventArgs>? ContactDeleted;
    public event EventHandler? BackFromDetail;

    // PROPERTIES
    public List<Contact> Contacts
    {
        get => _contacts;
        set
        {
            _contacts = value ?? new();
            UpdateActiveLetters();
            RefreshContactList();
        }
    }

    public Contact? SelectedContact => _selectedContact;

    public AgendaControl()
    {
        DoubleBuffered = true;
        BackColor = ThemeManager.CurrentTheme.PrimaryBackground;

        _tabsPanel = new AlphabeticalTabsPanel
        {
            Dock = DockStyle.Left,
            Width = 28
        };
        _tabsPanel.LetterSelected += (_, _) => RefreshContactList();

        _listPanel = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = ThemeManager.CurrentTheme.PrimaryBackground,
            Padding = new Padding(10)
        };

        _contactsContainer = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoScroll = true,
            WrapContents = true,
            Padding = new Padding(5),
            BackColor = Color.Transparent
        };

        _emptyLabel = new Label
        {
            Font = new Font("Segoe UI", 10f),
            ForeColor = ThemeManager.CurrentTheme.MutedText,
            AutoSize = true,
            Visible = false
        };

        _listPanel.Controls.Add(_contactsContainer);
        _listPanel.Controls.Add(_emptyLabel);

        _detailPanel = new ContactDetailPanel
        {
            Dock = DockStyle.Fill,
            Visible = false
        };
        _detailPanel.BackRequested += (_, _) => HideContactDetail();
        _detailPanel.ContactModified += DetailPanel_ContactModified;
        _detailPanel.ContactDeleting += DetailPanel_ContactDeleting;

        Controls.Add(_listPanel);
        Controls.Add(_detailPanel);
        Controls.Add(_tabsPanel);

        ThemeManager.ThemeChanged += (_, _) => ApplyTheme();
    }

    // ========================
    // PUBLIC API (RESTORED)
    // ========================

    public void NavigateToLetter(char letter)
    {
        _tabsPanel.SelectedLetter = char.ToUpper(letter);
    }

    public void AddContact(Contact contact)
    {
        _contacts.Add(contact);
        UpdateActiveLetters();
        _tabsPanel.SelectedLetter = contact.AlphabeticalKey;
        RefreshContactList();
    }

    public List<Contact> SearchContacts(string query)
    {
        if (string.IsNullOrWhiteSpace(query))
            return _contacts.ToList();

        var q = query.ToLower();

        return _contacts.Where(c =>
            c.FullName.ToLower().Contains(q) ||
            (!string.IsNullOrEmpty(c.Organization) && c.Organization.ToLower().Contains(q)) ||
            c.PhoneNumbers.Any(p => p.Number.Contains(query)) ||
            c.Emails.Any(e => e.Email.ToLower().Contains(q))
        ).ToList();
    }

    // ========================
    // INTERNAL LOGIC
    // ========================

    private void UpdateActiveLetters()
    {
        var letters = _contacts
            .Select(c => c.AlphabeticalKey)
            .Distinct()
            .OrderBy(c => c)
            .ToList();

        if (_contacts.Any(c => c.IsFavorite))
            letters.Insert(0, FavoritesChar);

        _tabsPanel.SetActiveLetters(letters);
    }

    private void RefreshContactList()
    {
        if (_contactsContainer == null || _tabsPanel == null)
            return;

        _contactsContainer.Controls.Clear();

        var selected = _tabsPanel.SelectedLetter;
        List<Contact> filtered;

        if (selected == FavoritesChar)
        {
            filtered = _contacts
                .Where(c => c.IsFavorite)
                .OrderBy(c => c.FirstName)
                .ThenBy(c => c.LastName)
                .ToList();

            _emptyLabel.Text = "No hay contactos favoritos";
        }
        else
        {
            filtered = _contacts
                .Where(c => c.AlphabeticalKey == selected)
                .OrderBy(c => c.FirstName)
                .ThenBy(c => c.LastName)
                .ToList();

            _emptyLabel.Text = "No hay contactos para esta letra";
        }

        if (filtered.Count == 0)
        {
            _emptyLabel.Visible = true;
            CenterEmptyLabel();
            return;
        }

        _emptyLabel.Visible = false;

        foreach (var contact in filtered)
        {
            var card = new ContactCard
            {
                Contact = contact,
                Margin = new Padding(5)
            };
            card.ContactClicked += ContactCard_Clicked;
            _contactsContainer.Controls.Add(card);
        }
    }

    private void CenterEmptyLabel()
    {
        if (_emptyLabel == null || _listPanel == null)
            return;

        _emptyLabel.Location = new Point(
            (_listPanel.Width - _emptyLabel.Width) / 2,
            (_listPanel.Height - _emptyLabel.Height) / 2
        );
    }

    private void ContactCard_Clicked(object? sender, ContactEventArgs e)
    {
        _selectedContact = e.Contact;
        ContactSelected?.Invoke(this, e);
        ShowContactDetail(e.Contact);
    }

    private void ShowContactDetail(Contact contact)
    {
        _detailPanel.Contact = contact;
        _listPanel.Visible = false;
        _tabsPanel.Visible = false;
        _detailPanel.Visible = true;
        _showingDetail = true;
    }

    private void HideContactDetail()
    {
        _detailPanel.Visible = false;
        _listPanel.Visible = true;
        _tabsPanel.Visible = true;
        _showingDetail = false;

        BackFromDetail?.Invoke(this, EventArgs.Empty);
        RefreshContactList();
    }

    private void DetailPanel_ContactModified(object? sender, ContactModifiedEventArgs e)
    {
        var idx = _contacts.FindIndex(c => c.Id == e.Contact.Id);
        if (idx >= 0)
            _contacts[idx] = e.Contact;

        ContactModified?.Invoke(this, e);
        UpdateActiveLetters();
        RefreshContactList();
    }

    private void DetailPanel_ContactDeleting(object? sender, ContactDeleteEventArgs e)
    {
        ContactDeleting?.Invoke(this, e);

        if (!e.Cancel)
        {
            _contacts.RemoveAll(c => c.Id == e.Contact.Id);
            ContactDeleted?.Invoke(this, new ContactEventArgs(e.Contact));
            UpdateActiveLetters();
            RefreshContactList();
        }
    }

    private void ApplyTheme()
    {
        BackColor = ThemeManager.CurrentTheme.PrimaryBackground;
        _listPanel.BackColor = ThemeManager.CurrentTheme.PrimaryBackground;
        _emptyLabel.ForeColor = ThemeManager.CurrentTheme.MutedText;
        RefreshContactList();
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);

        if (_emptyLabel != null && _emptyLabel.Visible)
            CenterEmptyLabel();
    }
}
