using System.ComponentModel;

namespace AgendaControls.Models;

/// <summary>
/// Representa un contacto en la agenda con toda su información asociada.
/// La integración de INotifyPropertyChanged permite que todos los cambios
/// queden reflejados automáticamente.
/// </summary>
public class Contact : INotifyPropertyChanged
{
    private Guid _id = Guid.NewGuid();
    private string _firstName = string.Empty;
    private string _lastName = string.Empty;
    private string _organization = string.Empty;
    private string _namePronunciation = string.Empty;
    private byte[]? _profileImage;
    private bool _isFavorite;
    private DateTime _createdAt = DateTime.Now;
    private DateTime _modifiedAt = DateTime.Now;

    public event PropertyChangedEventHandler? PropertyChanged;

    public Guid Id
    {
        get => _id;
        set { _id = value; OnPropertyChanged(nameof(Id)); }
    }

    public string FirstName
    {
        get => _firstName;
        set { _firstName = value; OnPropertyChanged(nameof(FirstName)); OnPropertyChanged(nameof(FullName)); OnPropertyChanged(nameof(Initials)); }
    }

    public string LastName
    {
        get => _lastName;
        set { _lastName = value; OnPropertyChanged(nameof(LastName)); OnPropertyChanged(nameof(FullName)); OnPropertyChanged(nameof(Initials)); }
    }

    public string FullName => $"{FirstName} {LastName}".Trim();

    public string Initials
    {
        get
        {
            var first = !string.IsNullOrEmpty(FirstName) ? FirstName[0].ToString().ToUpper() : "";
            var last = !string.IsNullOrEmpty(LastName) ? LastName[0].ToString().ToUpper() : "";
            return $"{first}{last}";
        }
    }

    public string Organization
    {
        get => _organization;
        set { _organization = value; OnPropertyChanged(nameof(Organization)); }
    }

    public string NamePronunciation
    {
        get => _namePronunciation;
        set { _namePronunciation = value; OnPropertyChanged(nameof(NamePronunciation)); }
    }

    public byte[]? ProfileImage
    {
        get => _profileImage;
        set { _profileImage = value; OnPropertyChanged(nameof(ProfileImage)); }
    }

    public bool IsFavorite
    {
        get => _isFavorite;
        set { _isFavorite = value; OnPropertyChanged(nameof(IsFavorite)); }
    }

    public DateTime CreatedAt
    {
        get => _createdAt;
        set { _createdAt = value; OnPropertyChanged(nameof(CreatedAt)); }
    }

    public DateTime ModifiedAt
    {
        get => _modifiedAt;
        set { _modifiedAt = value; OnPropertyChanged(nameof(ModifiedAt)); }
    }

    public List<PhoneNumber> PhoneNumbers { get; set; } = new();
    public List<EmailAddress> Emails { get; set; } = new();
    public List<PhysicalAddress> Addresses { get; set; } = new();
    public List<SocialMedia> SocialMediaLinks { get; set; } = new();
    public List<ContactNote> Notes { get; set; } = new();
    public Dictionary<string, string> CustomFields { get; set; } = new();

    /// <summary>
    /// Obtiene el número de teléfono principal (el primero en la lista).
    /// </summary>
    public string? PrimaryPhone => PhoneNumbers.FirstOrDefault()?.Number;

    /// <summary>
    /// Obtiene el email principal (el primero en la lista).
    /// </summary>
    public string? PrimaryEmail => Emails.FirstOrDefault()?.Email;

    /// <summary>
    /// Obtiene la primera letra del nombre para el orden alfabético.
    /// Si no hay nada en el nombre, hace fallback als apellido.
    /// </summary>
    public char AlphabeticalKey
    {
        get
        {
            if (!string.IsNullOrEmpty(FirstName))
                return char.ToUpper(FirstName[0]);
            if (!string.IsNullOrEmpty(LastName))
                return char.ToUpper(LastName[0]);
            return '#';
        }
    }

    /// <summary>
    /// Notifica que una propiedad ha cambiado y actualiza la fecha de última modificación.
    /// </summary>
    protected virtual void OnPropertyChanged(string propertyName)
    {
        // Evita recursión infinita: no actualizar ModifiedAt cuando cambia ModifiedAt
        if (propertyName != nameof(ModifiedAt))
        {
            _modifiedAt = DateTime.Now;
        }
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    /// <summary>
    /// Crea una copia profunda del contacto.
    /// Esto permite volver atrás en caso de cancelar los cambios al editar.
    /// </summary>
    public Contact Clone()
    {
        var clone = new Contact
        {
            Id = this.Id,
            FirstName = this.FirstName,
            LastName = this.LastName,
            Organization = this.Organization,
            NamePronunciation = this.NamePronunciation,
            ProfileImage = this.ProfileImage?.ToArray(),
            IsFavorite = this.IsFavorite,
            CreatedAt = this.CreatedAt,
            ModifiedAt = this.ModifiedAt
        };

        clone.PhoneNumbers = this.PhoneNumbers.Select(p => p.Clone()).ToList();
        clone.Emails = this.Emails.Select(e => e.Clone()).ToList();
        clone.Addresses = this.Addresses.Select(a => a.Clone()).ToList();
        clone.SocialMediaLinks = this.SocialMediaLinks.Select(s => s.Clone()).ToList();
        clone.Notes = this.Notes.Select(n => n.Clone()).ToList();
        clone.CustomFields = new Dictionary<string, string>(this.CustomFields);

        return clone;
    }
}

/// <summary>
/// Representa un número de teléfono con su etiqueta.
/// </summary>
public class PhoneNumber
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Label { get; set; } = "Móvil";
    public string Number { get; set; } = string.Empty;

    public PhoneNumber Clone() => new()
    {
        Id = this.Id,
        Label = this.Label,
        Number = this.Number
    };
}

/// <summary>
/// Representa un email con su etiqueta.
/// </summary>
public class EmailAddress
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Label { get; set; } = "Personal";
    public string Email { get; set; } = string.Empty;

    public EmailAddress Clone() => new()
    {
        Id = this.Id,
        Label = this.Label,
        Email = this.Email
    };
}

/// <summary>
/// Representa una dirección.
/// </summary>
public class PhysicalAddress
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Label { get; set; } = "Casa";
    public string Street1 { get; set; } = string.Empty;
    public string Street2 { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string Province { get; set; } = string.Empty;
    public string PostalCode { get; set; } = string.Empty;
    public string Country { get; set; } = string.Empty;

    public string FormattedAddress
    {
        get
        {
            var parts = new List<string>();
            if (!string.IsNullOrEmpty(Street1)) parts.Add(Street1);
            if (!string.IsNullOrEmpty(Street2)) parts.Add(Street2);
            
            var cityLine = string.Join(", ", 
                new[] { PostalCode, City }.Where(s => !string.IsNullOrEmpty(s)));
            if (!string.IsNullOrEmpty(cityLine)) parts.Add(cityLine);
            
            var regionLine = string.Join(", ", 
                new[] { Province, Country }.Where(s => !string.IsNullOrEmpty(s)));
            if (!string.IsNullOrEmpty(regionLine)) parts.Add(regionLine);
            
            return string.Join("\n", parts);
        }
    }

    public PhysicalAddress Clone() => new()
    {
        Id = this.Id,
        Label = this.Label,
        Street1 = this.Street1,
        Street2 = this.Street2,
        City = this.City,
        Province = this.Province,
        PostalCode = this.PostalCode,
        Country = this.Country
    };
}

/// <summary>
/// Representa un enlace a red social.
/// </summary>
public class SocialMedia
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Platform { get; set; } = string.Empty;
    public string Username { get; set; } = string.Empty;
    public string Url { get; set; } = string.Empty;

    public SocialMedia Clone() => new()
    {
        Id = this.Id,
        Platform = this.Platform,
        Username = this.Username,
        Url = this.Url
    };
}

/// <summary>
/// Representa una nota.
/// </summary>
public class ContactNote
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Content { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public ContactNote Clone() => new()
    {
        Id = this.Id,
        Content = this.Content,
        CreatedAt = this.CreatedAt
    };
}
