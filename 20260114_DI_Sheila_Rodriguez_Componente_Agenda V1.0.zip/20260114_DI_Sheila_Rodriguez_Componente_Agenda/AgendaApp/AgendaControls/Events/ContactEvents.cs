using AgendaControls.Models;

namespace AgendaControls.Events;

/// <summary>
/// Argumentos de evento para eventos relacionados con contactos.
/// </summary>
public class ContactEventArgs : EventArgs
{
    public Contact Contact { get; }

    public ContactEventArgs(Contact contact)
    {
        Contact = contact;
    }
}

/// <summary>
/// Argumentos de evento para eventos de modificaci�n de contactos.
/// </summary>
public class ContactModifiedEventArgs : ContactEventArgs
{
    public Contact OriginalContact { get; }
    public ModificationType ModificationType { get; }

    public ContactModifiedEventArgs(Contact contact, Contact originalContact, ModificationType modificationType) 
        : base(contact)
    {
        OriginalContact = originalContact;
        ModificationType = modificationType;
    }
}

/// <summary>
/// Argumentos de evento para la eliminaci�n de contactos con confirmaci�n.
/// </summary>
public class ContactDeleteEventArgs : ContactEventArgs
{
    public bool Cancel { get; set; }

    public ContactDeleteEventArgs(Contact contact) : base(contact)
    {
    }
}

/// <summary>
/// Argumentos de evento para eventos de adici�n de campos.
/// </summary>
public class FieldAddedEventArgs : ContactEventArgs
{
    public FieldType FieldType { get; }
    public object FieldValue { get; }

    public FieldAddedEventArgs(Contact contact, FieldType fieldType, object fieldValue) 
        : base(contact)
    {
        FieldType = fieldType;
        FieldValue = fieldValue;
    }
}

/// <summary>
/// Tipos de modificaciones que se pueden realizar sobre un contacto.
/// </summary>
public enum ModificationType
{
    Created,
    Updated,
    Deleted,
    FieldAdded,
    FieldRemoved
}

/// <summary>
/// Tipos de campos que se pueden a�adir a un contacto.
/// </summary>
public enum FieldType
{
    Phone,
    Email,
    Address,
    SocialMedia,
    Note,
    CustomField,
    Pronunciation
}
