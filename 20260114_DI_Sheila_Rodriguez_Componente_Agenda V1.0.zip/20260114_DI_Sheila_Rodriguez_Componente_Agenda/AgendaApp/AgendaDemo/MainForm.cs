using AgendaControls.Controls;
using AgendaControls.Models;
using AgendaControls.Themes;
using AgendaControls.Events;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace AgendaDemo
{
    public class MainForm : Form
    {
        private readonly AgendaControl _agendaControl;
        private readonly Panel _toolbarPanel;
        private readonly TextBox _searchBox;
        private readonly Button _addButton;
        private readonly Button _themeButton;
        private readonly Label _titleLabel;
        private bool _isDarkTheme = true;

        public MainForm()
        {
            // Form setup
            Text = "Agenda - Demo Application";
            Size = new Size(450, 700);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            BackColor = ThemeManager.CurrentTheme.PrimaryBackground;

            // Toolbar panel
            _toolbarPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 55,
                BackColor = ThemeManager.CurrentTheme.SecondaryBackground,
                Padding = new Padding(10)
            };

            // Title
            _titleLabel = new Label
            {
                Text = "AGENDA",
                Font = new Font("Segoe UI Semibold", 12f),
                ForeColor = ThemeManager.CurrentTheme.PrimaryText,
                AutoSize = true,
                Location = new Point(10, 17)
            };

            // Add contact button
            _addButton = new Button
            {
                Text = "+ Añadir",
                Size = new Size(75, 28),
                Location = new Point(100, 15),
                FlatStyle = FlatStyle.Flat,
                BackColor = ThemeManager.CurrentTheme.AccentBlue,
                ForeColor = Color.White,
                Font = new Font("Segoe UI Semibold", 8.5f),
                Cursor = Cursors.Hand
            };
            _addButton.FlatAppearance.BorderSize = 0;
            _addButton.Click += AddButton_Click;

            // Theme toggle button
            _themeButton = new Button
            {
                Text = "☀",
                Size = new Size(32, 28),
                Location = new Point(400, 13),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.Transparent,
                ForeColor = ThemeManager.CurrentTheme.PrimaryText,
                Font = new Font("Segoe UI", 12f),
                Cursor = Cursors.Hand
            };
            _themeButton.FlatAppearance.BorderSize = 0;
            _themeButton.Click += ThemeButton_Click;

            _toolbarPanel.Controls.Add(_titleLabel);
            _toolbarPanel.Controls.Add(_addButton);
            _toolbarPanel.Controls.Add(_themeButton);

            // Main agenda control
            _agendaControl = new AgendaControl
            {
                Dock = DockStyle.Fill
            };
            _agendaControl.ContactSelected += AgendaControl_ContactSelected;
            _agendaControl.ContactModified += AgendaControl_ContactModified;
            _agendaControl.ContactDeleted += AgendaControl_ContactDeleted;
            _agendaControl.BackFromDetail += AgendaControl_BackFromDetail;

            // Add controls
            Controls.Add(_agendaControl);
            Controls.Add(_toolbarPanel);

            // Load sample data
            LoadSampleContacts();

            // Subscribe to theme changes
            ThemeManager.ThemeChanged += (s, e) => ApplyTheme();
        }

        private void LoadSampleContacts()
        {
            var contacts = new List<Contact>
    {
        new Contact
        {
            FirstName = "Ana",
            LastName = "García",
            Organization = "Tech Solutions",
            PhoneNumbers = new List<PhoneNumber>
            {
                new() { Label = "Móvil", Number = "+34 612 345 678" },
                new() { Label = "Trabajo", Number = "+34 912 345 678" }
            },
            Emails = new List<EmailAddress>
            {
                new() { Label = "Personal", Email = "ana.garcia@email.com" }
            }
        },
        new Contact
        {
            FirstName = "Carlos",
            LastName = "Martínez",
            Organization = "Design Studio",
            PhoneNumbers = new List<PhoneNumber>
            {
                new() { Label = "Móvil", Number = "+34 623 456 789" }
            },
            Emails = new List<EmailAddress>
            {
                new() { Label = "Trabajo", Email = "carlos@designstudio.es" }
            },
            Addresses = new List<PhysicalAddress>
            {
                new()
                {
                    Label = "Oficina",
                    Street1 = "Calle Gran Vía, 45",
                    City = "Madrid",
                    PostalCode = "28013",
                    Country = "España"
                }
            }
        },
        new Contact
        {
            FirstName = "Elena",
            LastName = "López",
            Organization = "Consulting Group",
            PhoneNumbers = new List<PhoneNumber>
            {
                new() { Label = "Móvil", Number = "+34 634 567 890" }
            },
            Emails = new List<EmailAddress>
            {
                new() { Label = "Personal", Email = "elena.lopez@gmail.com" }
            },
            SocialMediaLinks = new List<SocialMedia>
            {
                new() { Platform = "LinkedIn", Username = "elenalopez" }
            },
            Notes = new List<ContactNote>
            {
                new() { Content = "Reunión pendiente para Q2" }
            }
        },
        new Contact
        {
            FirstName = "Francisco",
            LastName = "Ruiz",
            PhoneNumbers = new List<PhoneNumber>
            {
                new() { Label = "Casa", Number = "+34 956 123 456" }
            }
        },
        new Contact
        {
            FirstName = "Isabel",
            LastName = "Sánchez",
            Organization = "Hospital Central",
            PhoneNumbers = new List<PhoneNumber>
            {
                new() { Label = "Móvil", Number = "+34 645 678 901" }
            },
            IsFavorite = true
        },
        new Contact
        {
            FirstName = "Jorge",
            LastName = "Fernández",
            PhoneNumbers = new List<PhoneNumber>
            {
                new() { Label = "Móvil", Number = "+34 656 789 012" }
            }
        },
        new Contact
        {
            FirstName = "Laura",
            LastName = "Díaz",
            Organization = "Marketing Agency",
            PhoneNumbers = new List<PhoneNumber>
            {
                new() { Label = "Trabajo", Number = "+34 667 890 123" }
            },
            Emails = new List<EmailAddress>
            {
                new() { Label = "Trabajo", Email = "laura@marketingagency.es" }
            }
        },
        new Contact
        {
            FirstName = "Miguel",
            LastName = "Torres",
            PhoneNumbers = new List<PhoneNumber>
            {
                new() { Label = "Móvil", Number = "+34 678 901 234" }
            }
        },
        new Contact
        {
            FirstName = "Ana",
            LastName = "Guerra",
            Organization = "ORGANIZACIÓN",
            PhoneNumbers = new List<PhoneNumber>
            {
                new() { Label = "Móvil", Number = "+34 654 123 456" },
                new() { Label = "Fijo", Number = "976 123 456" }
            },
            Emails = new List<EmailAddress>
            {
                new() { Label = "Personal", Email = "mail@ejemplo.com" }
            }
        },
        new Contact
        {
            FirstName = "Pablo",
            LastName = "Hernández",
            PhoneNumbers = new List<PhoneNumber>
            {
                new() { Label = "Móvil", Number = "+34 689 012 345" }
            }
        },
        new Contact
        {
            FirstName = "Rosa",
            LastName = "Jiménez",
            Organization = "Law Firm",
            PhoneNumbers = new List<PhoneNumber>
            {
                new() { Label = "Trabajo", Number = "+34 690 123 456" }
            },
            IsFavorite = true
        },
        new Contact
        {
            FirstName = "Sergio",
            LastName = "Moreno",
            PhoneNumbers = new List<PhoneNumber>
            {
                new() { Label = "Móvil", Number = "+34 601 234 567" }
            }
        }
    };

            _agendaControl.Contacts = contacts;
            _agendaControl.NavigateToLetter('A'); // Start at A
        }


        private void AddButton_Click(object? sender, EventArgs e)
        {
            using var dialog = new AddContactDialog();
            if (dialog.ShowDialog(this) == DialogResult.OK && dialog.NewContact != null)
            {
                _agendaControl.AddContact(dialog.NewContact);
            }
        }

        private void ThemeButton_Click(object? sender, EventArgs e)
        {
            _isDarkTheme = !_isDarkTheme;
            if (_isDarkTheme)
            {
                ThemeManager.ApplyDarkTheme();
                _themeButton.Text = "☀";
            }
            else
            {
                ThemeManager.ApplyLightTheme();
                _themeButton.Text = "🌙";
            }
        }

        private void AgendaControl_ContactSelected(object? sender, ContactEventArgs e)
        {
            _toolbarPanel.Visible = false;
        }

        private void AgendaControl_BackFromDetail(object? sender, EventArgs e)
        {
            _toolbarPanel.Visible = true;
        }

        private void AgendaControl_ContactModified(object? sender, ContactModifiedEventArgs e)
        {
            Console.WriteLine($"Contact modified: {e.Contact.FullName} - {e.ModificationType}");
        }

        private void AgendaControl_ContactDeleted(object? sender, ContactEventArgs e)
        {
            _toolbarPanel.Visible = true;
            Console.WriteLine($"Contact deleted: {e.Contact.FullName}");
        }

        private void ApplyTheme()
        {
            BackColor = ThemeManager.CurrentTheme.PrimaryBackground;
            _toolbarPanel.BackColor = ThemeManager.CurrentTheme.SecondaryBackground;
            _titleLabel.ForeColor = ThemeManager.CurrentTheme.PrimaryText;
            _addButton.BackColor = ThemeManager.CurrentTheme.AccentBlue;
            _themeButton.ForeColor = ThemeManager.CurrentTheme.PrimaryText;
            Refresh();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
        }
    }

    /// <summary>
    /// Dialog para añadir un contacto nuevo con botones centrados.
    /// </summary>
    public class AddContactDialog : Form
    {
        private readonly StyledTextBox _firstNameBox;
        private readonly StyledTextBox _lastNameBox;
        private readonly StyledTextBox _organizationBox;
        private readonly StyledTextBox _phoneBox;
        private readonly StyledTextBox _emailBox;

        private readonly StyledButton _saveButton;
        private readonly StyledButton _cancelButton;

        public Contact? NewContact { get; private set; }

        public AddContactDialog()
        {
            Text = "Añadir Contacto";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterParent;
            MaximizeBox = false;
            MinimizeBox = false;
            BackColor = ThemeManager.CurrentTheme.ModalBackground;

            var contentWidth = 320;
            var yPos = 20;
            var spacing = 60; // Aumentado para evitar solapamiento de labels

            // Campos
            _firstNameBox = new StyledTextBox
            {
                Label = "Nombre",
                Location = new Point(20, yPos),
                Size = new Size(contentWidth, 44)
            };
            yPos += spacing;

            _lastNameBox = new StyledTextBox
            {
                Label = "Apellidos",
                Location = new Point(20, yPos),
                Size = new Size(contentWidth, 44)
            };
            yPos += spacing;

            _organizationBox = new StyledTextBox
            {
                Label = "Organización",
                Location = new Point(20, yPos),
                Size = new Size(contentWidth, 44)
            };
            yPos += spacing;

            _phoneBox = new StyledTextBox
            {
                Label = "Teléfono",
                Location = new Point(20, yPos),
                Size = new Size(contentWidth, 44)
            };
            yPos += spacing;

            _emailBox = new StyledTextBox
            {
                Label = "Email",
                Location = new Point(20, yPos),
                Size = new Size(contentWidth, 44)
            };
            yPos += spacing;

            Controls.Add(_firstNameBox);
            Controls.Add(_lastNameBox);
            Controls.Add(_organizationBox);
            Controls.Add(_phoneBox);
            Controls.Add(_emailBox);

            // Botones centrados
            var buttonY = yPos;
            var buttonWidth = 100;
            var buttonHeight = 35;
            var spacingButtons = 20;
            var totalWidth = buttonWidth * 2 + spacingButtons;
            var startX = (contentWidth + 40 - totalWidth) / 2; // 40 = padding lateral del form

            _saveButton = new StyledButton
            {
                Text = "Guardar",
                Style = StyledButton.ButtonStyle.Primary,
                Size = new Size(buttonWidth, buttonHeight),
                Location = new Point(startX, buttonY)
            };
            _saveButton.Click += SaveButton_Click;

            _cancelButton = new StyledButton
            {
                Text = "Cancelar",
                Style = StyledButton.ButtonStyle.Secondary,
                Size = new Size(buttonWidth, buttonHeight),
                Location = new Point(startX + buttonWidth + spacingButtons, buttonY)
            };
            _cancelButton.Click += (s, e) =>
            {
                DialogResult = DialogResult.Cancel;
                Close();
            };

            Controls.Add(_saveButton);
            Controls.Add(_cancelButton);

            // Ajusta el tamaño del formulario al contenido
            ClientSize = new Size(contentWidth + 40, buttonY + buttonHeight + 20);
        }

        private void SaveButton_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_firstNameBox.Text) && string.IsNullOrWhiteSpace(_lastNameBox.Text))
            {
                MessageBox.Show("Introduce al menos un nombre o apellido.", "Validación",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            NewContact = new Contact
            {
                FirstName = _firstNameBox.Text.Trim(),
                LastName = _lastNameBox.Text.Trim(),
                Organization = _organizationBox.Text.Trim()
            };

            if (!string.IsNullOrWhiteSpace(_phoneBox.Text))
            {
                NewContact.PhoneNumbers.Add(new PhoneNumber
                {
                    Label = "Móvil",
                    Number = _phoneBox.Text.Trim()
                });
            }

            if (!string.IsNullOrWhiteSpace(_emailBox.Text))
            {
                NewContact.Emails.Add(new EmailAddress
                {
                    Label = "Personal",
                    Email = _emailBox.Text.Trim()
                });
            }

            DialogResult = DialogResult.OK;
            Close();
        }
    }
}

