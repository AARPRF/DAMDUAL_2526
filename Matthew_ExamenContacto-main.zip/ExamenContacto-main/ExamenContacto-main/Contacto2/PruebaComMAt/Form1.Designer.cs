﻿namespace PruebaComMAt
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            inputbox1 = new Contacto2.Inputbox();
            contacto1 = new Contacto2.Contacto();
            SuspendLayout();
            // 
            // inputbox1
            // 
            inputbox1.HeaderBackColor = SystemColors.Control;
            inputbox1.HeaderForeColor = SystemColors.ControlText;
            inputbox1.HeaderText = "label1";
            inputbox1.HeaderTypography = new Font("Segoe UI", 9F);
            inputbox1.InputBackColor = SystemColors.Window;
            inputbox1.InputForeColor = SystemColors.WindowText;
            inputbox1.InputTypography = new Font("Segoe UI", 9F);
            inputbox1.Location = new Point(45, 39);
            inputbox1.Margin = new Padding(4, 5, 4, 5);
            inputbox1.Name = "inputbox1";
            inputbox1.Size = new Size(801, 78);
            inputbox1.TabIndex = 0;
            inputbox1.Value = "";
            // 
            // contacto1
            // 
            contacto1.Location = new Point(45, 136);
            contacto1.Margin = new Padding(4, 5, 4, 5);
            contacto1.Name = "contacto1";
            contacto1.Size = new Size(705, 332);
            contacto1.TabIndex = 1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1098, 860);
            Controls.Add(contacto1);
            Controls.Add(inputbox1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Contacto2.Inputbox inputbox1;
        private Contacto2.Contacto contacto1;
    }
}
