﻿namespace Contacto2
{
    partial class panelEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            panelheader = new Panel();
            pictureBoxSave = new PictureBox();
            pictureBoxPhoto = new PictureBox();
            flowbody = new FlowLayoutPanel();
            panelbody = new Panel();
            inputboxTelefono = new Inputbox();
            inputbox1 = new Inputbox();
            inputboxnombre = new Inputbox();
            tableLayoutPanel1.SuspendLayout();
            panelheader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxSave).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxPhoto).BeginInit();
            flowbody.SuspendLayout();
            panelbody.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Controls.Add(panelheader, 0, 0);
            tableLayoutPanel1.Controls.Add(flowbody, 0, 1);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 32.55132F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 67.44868F));
            tableLayoutPanel1.Size = new Size(387, 304);
            tableLayoutPanel1.TabIndex = 1;
            // 
            // panelheader
            // 
            panelheader.BackColor = Color.LightGreen;
            panelheader.Controls.Add(pictureBoxSave);
            panelheader.Controls.Add(pictureBoxPhoto);
            panelheader.Dock = DockStyle.Fill;
            panelheader.Location = new Point(3, 3);
            panelheader.Name = "panelheader";
            panelheader.Size = new Size(381, 92);
            panelheader.TabIndex = 0;
            // 
            // pictureBoxSave
            // 
            pictureBoxSave.Image = Properties.Resources.save;
            pictureBoxSave.Location = new Point(302, 20);
            pictureBoxSave.Name = "pictureBoxSave";
            pictureBoxSave.Size = new Size(56, 36);
            pictureBoxSave.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxSave.TabIndex = 1;
            pictureBoxSave.TabStop = false;
            pictureBoxSave.Click += pictureBoxSave_Click;
            // 
            // pictureBoxPhoto
            // 
            pictureBoxPhoto.Image = Properties.Resources.user;
            pictureBoxPhoto.Location = new Point(20, 20);
            pictureBoxPhoto.Name = "pictureBoxPhoto";
            pictureBoxPhoto.Size = new Size(84, 50);
            pictureBoxPhoto.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxPhoto.TabIndex = 0;
            pictureBoxPhoto.TabStop = false;
            pictureBoxPhoto.Click += pictureBoxPhoto_Click;
            // 
            // flowbody
            // 
            flowbody.AutoScroll = true;
            flowbody.Controls.Add(panelbody);
            flowbody.Dock = DockStyle.Fill;
            flowbody.FlowDirection = FlowDirection.TopDown;
            flowbody.Location = new Point(3, 101);
            flowbody.Name = "flowbody";
            flowbody.Size = new Size(381, 200);
            flowbody.TabIndex = 1;
            flowbody.WrapContents = false;
            // 
            // panelbody
            // 
            panelbody.Controls.Add(inputboxTelefono);
            panelbody.Controls.Add(inputbox1);
            panelbody.Controls.Add(inputboxnombre);
            panelbody.Location = new Point(3, 3);
            panelbody.Name = "panelbody";
            panelbody.Size = new Size(369, 284);
            panelbody.TabIndex = 0;
            // 
            // inputboxTelefono
            // 
            inputboxTelefono.HeaderBackColor = SystemColors.Control;
            inputboxTelefono.HeaderForeColor = SystemColors.ControlText;
            inputboxTelefono.HeaderText = "Telefono";
            inputboxTelefono.HeaderTypography = new Font("Segoe UI", 9F);
            inputboxTelefono.InputBackColor = SystemColors.Window;
            inputboxTelefono.InputForeColor = SystemColors.WindowText;
            inputboxTelefono.InputTypography = new Font("Segoe UI", 9F);
            inputboxTelefono.Location = new Point(-6, 61);
            inputboxTelefono.Name = "inputboxTelefono";
            inputboxTelefono.Size = new Size(361, 31);
            inputboxTelefono.TabIndex = 2;
            inputboxTelefono.Value = "";
            // 
            // inputbox1
            // 
            inputbox1.HeaderBackColor = SystemColors.Control;
            inputbox1.HeaderForeColor = SystemColors.ControlText;
            inputbox1.HeaderText = "Email";
            inputbox1.HeaderTypography = new Font("Segoe UI", 9F);
            inputbox1.InputBackColor = SystemColors.Window;
            inputbox1.InputForeColor = SystemColors.WindowText;
            inputbox1.InputTypography = new Font("Segoe UI", 9F);
            inputbox1.Location = new Point(-8, 116);
            inputbox1.Name = "inputbox1";
            inputbox1.Size = new Size(363, 31);
            inputbox1.TabIndex = 1;
            inputbox1.Value = "";
            // 
            // inputboxnombre
            // 
            inputboxnombre.HeaderBackColor = SystemColors.Control;
            inputboxnombre.HeaderForeColor = SystemColors.ControlText;
            inputboxnombre.HeaderText = "Nombre";
            inputboxnombre.HeaderTypography = new Font("Segoe UI", 9F);
            inputboxnombre.InputBackColor = SystemColors.Window;
            inputboxnombre.InputForeColor = SystemColors.WindowText;
            inputboxnombre.InputTypography = new Font("Segoe UI", 9F);
            inputboxnombre.Location = new Point(0, 13);
            inputboxnombre.Name = "inputboxnombre";
            inputboxnombre.Size = new Size(355, 31);
            inputboxnombre.TabIndex = 0;
            inputboxnombre.Value = "";
            // 
            // panelEdit
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoValidate = AutoValidate.EnablePreventFocusChange;
            ClientSize = new Size(387, 304);
            ControlBox = false;
            Controls.Add(tableLayoutPanel1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "panelEdit";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Edicion de contacto";
            tableLayoutPanel1.ResumeLayout(false);
            panelheader.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBoxSave).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxPhoto).EndInit();
            flowbody.ResumeLayout(false);
            panelbody.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Panel panelheader;
        private PictureBox pictureBoxSave;
        private PictureBox pictureBoxPhoto;
        private FlowLayoutPanel flowbody;
        private Panel panelbody;
        private Inputbox inputboxnombre;
        private Inputbox inputboxTelefono;
        private Inputbox inputbox1;
    }
}