﻿namespace Contacto2
{
    partial class Contacto
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            panelheader = new Panel();
            pictureBoxEdit = new PictureBox();
            pictureBoxPhoto = new PictureBox();
            flowbody = new FlowLayoutPanel();
            labelDatos = new Label();
            tableLayoutPanel1.SuspendLayout();
            panelheader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxEdit).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxPhoto).BeginInit();
            flowbody.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Controls.Add(panelheader, 0, 0);
            tableLayoutPanel1.Controls.Add(flowbody, 0, 1);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 49.4444427F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50.5555573F));
            tableLayoutPanel1.Size = new Size(406, 180);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // panelheader
            // 
            panelheader.BackColor = Color.LightGreen;
            panelheader.Controls.Add(pictureBoxEdit);
            panelheader.Controls.Add(pictureBoxPhoto);
            panelheader.Dock = DockStyle.Fill;
            panelheader.Location = new Point(3, 3);
            panelheader.Name = "panelheader";
            panelheader.Size = new Size(400, 83);
            panelheader.TabIndex = 0;
            // 
            // pictureBoxEdit
            // 
            pictureBoxEdit.Image = Properties.Resources.edit_file;
            pictureBoxEdit.Location = new Point(320, 20);
            pictureBoxEdit.Name = "pictureBoxEdit";
            pictureBoxEdit.Size = new Size(56, 36);
            pictureBoxEdit.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxEdit.TabIndex = 1;
            pictureBoxEdit.TabStop = false;
            pictureBoxEdit.Click += pictureBox1_Click;
            // 
            // pictureBoxPhoto
            // 
            pictureBoxPhoto.Image = Properties.Resources.user;
            pictureBoxPhoto.Location = new Point(20, 20);
            pictureBoxPhoto.Name = "pictureBoxPhoto";
            pictureBoxPhoto.Size = new Size(84, 50);
            pictureBoxPhoto.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxPhoto.TabIndex = 0;
            pictureBoxPhoto.TabStop = false;
            pictureBoxPhoto.Click += pictureBoxPhoto_Click;
            // 
            // flowbody
            // 
            flowbody.AutoScroll = true;
            flowbody.Controls.Add(labelDatos);
            flowbody.Dock = DockStyle.Fill;
            flowbody.FlowDirection = FlowDirection.TopDown;
            flowbody.Location = new Point(3, 92);
            flowbody.Name = "flowbody";
            flowbody.Size = new Size(400, 85);
            flowbody.TabIndex = 1;
            flowbody.WrapContents = false;
            // 
            // labelDatos
            // 
            labelDatos.AutoSize = true;
            labelDatos.Location = new Point(3, 0);
            labelDatos.Name = "labelDatos";
            labelDatos.Size = new Size(38, 15);
            labelDatos.TabIndex = 1;
            labelDatos.Text = "label1";
            // 
            // Contacto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(tableLayoutPanel1);
            Name = "Contacto";
            Size = new Size(406, 180);
            tableLayoutPanel1.ResumeLayout(false);
            panelheader.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBoxEdit).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxPhoto).EndInit();
            flowbody.ResumeLayout(false);
            flowbody.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Panel panelheader;
        private FlowLayoutPanel flowbody;
        private PictureBox pictureBoxPhoto;
        private PictureBox pictureBoxEdit;
        private Label labelDatos;
    }
}
