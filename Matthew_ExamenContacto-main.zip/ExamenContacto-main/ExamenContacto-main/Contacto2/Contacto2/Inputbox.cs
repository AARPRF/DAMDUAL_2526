﻿namespace Contacto2
{
    public partial class Inputbox : UserControl
    {
 
        public event EventHandler InputEnter;
        public event EventHandler InputLeave;
        public event EventHandler InputTextChanged;


        public Inputbox()
        {
            InitializeComponent();

  
            Input.Enter += (s, e) => InputEnter?.Invoke(this, e);
            Input.Leave += (s, e) => InputLeave?.Invoke(this, e);
            Input.TextChanged += (s, e) => InputTextChanged?.Invoke(this, e);
        }

  
        public string Value
        {
            get => Input.Text;
            set
            {
                Input.Text = value;
            }
        }
        public string HeaderText
        {
            get => Header.Text;
            set =>  Header.Text = value;
        }

        #region // Tipografía y colores

        public Font HeaderTypography
        {
            get => Header.Font;
            set => Header.Font = value;
        }

        public Font InputTypography
        {
            get => Input.Font;
            set => Input.Font = value;
        }

        public Color HeaderBackColor
        {
            get => Header.BackColor;
            set => Header.BackColor = value;
        }

        public Color HeaderForeColor
        {
            get => Header.ForeColor;
            set => Header.ForeColor = value;
        }

        public Color InputBackColor
        {
            get => Input.BackColor;
            set => Input.BackColor = value;
        }

        public Color InputForeColor
        {
            get => Input.ForeColor;
            set => Input.ForeColor = value;
        }
        #endregion

   
    }
}
