﻿namespace Contacto2
{
    partial class Inputbox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Header = new Label();
            Input = new TextBox();
            SuspendLayout();
            // 
            // Header
            // 
            Header.Location = new Point(46, 0);
            Header.Name = "Header";
            Header.Size = new Size(100, 23);
            Header.TabIndex = 0;
            Header.Text = "label1";
            Header.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // Input
            // 
            Input.Location = new Point(152, 3);
            Input.Name = "Input";
            Input.Size = new Size(213, 23);
            Input.TabIndex = 1;
            // 
            // Inputbox
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(Input);
            Controls.Add(Header);
            Name = "Inputbox";
            Size = new Size(374, 31);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Header;
        private TextBox Input;
    }
}
