﻿using System.Data;

namespace Contacto2
{
    public partial class panelEdit : Form
    {
        public Image image;
        public DataTable dt = new DataTable();
        public panelEdit(Image image, DataTable dt)
        {
            InitializeComponent();
            this.image = image;
            this.dt = dt;
        }

        private void pictureBoxPhoto_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Title = "Elije una imagen";
                dlg.Filter = "Image Files (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png";
                dlg.Multiselect = false;
                if (dlg.ShowDialog() != DialogResult.OK)
                {
                    return;
                }

                string file = dlg.FileName;
                string ext = System.IO.Path.GetExtension(file)?.ToLowerInvariant() ?? string.Empty;
                if (ext != ".jpg" && ext != ".jpeg" && ext != ".png")
                {
                    MessageBox.Show("Solamente estan permitidas imagenes jpg y png.", "Invalid file type", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                try
                {
                    using (FileStream fs = new System.IO.FileStream(file, System.IO.FileMode.Open, System.IO.FileAccess.Read))
                    using (Image img = System.Drawing.Image.FromStream(fs))
                    {
                        // Create a copy so the stream can be closed safely
                        Bitmap bmp = new System.Drawing.Bitmap(img);
                        // Dispose previous image if any
                        Image prev = pictureBoxPhoto.Image;
                        pictureBoxPhoto.Image = bmp;
                        pictureBoxPhoto.SizeMode = PictureBoxSizeMode.Zoom;
                        prev?.Dispose();
                        image = bmp;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Fallo a la hora de la carga: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        private void guardardt()
        {
            dt.Columns.Clear();
            dt.Rows.Clear();
            dt.Columns.Add("Nombre");
            dt.Columns.Add("Telefono");
            dt.Columns.Add("Email");
            DataRow row = dt.NewRow();
            row["Nombre"] = inputboxnombre.Value;
            row["Telefono"] = inputboxTelefono.Value;
            row["Email"] = inputbox1.Value;
            dt.Rows.Add(row);
        }

        private void pictureBoxSave_Click(object sender, EventArgs e)
        {
            guardardt();
            this.Close();
        }
    }
}
