﻿using System.Data;

namespace Contacto2
{
    public partial class Contacto : UserControl
    {

        public DataTable dt = new DataTable();
        public Contacto()
        {
            InitializeComponent();
            configure();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            panelEdit frm = new panelEdit(pictureBoxPhoto.Image,dt);
            frm.ShowDialog();
            dt = frm.dt;
            configure();
            pictureBoxPhoto.Image = frm.image;
        }

        public void configure()
        {
            String texto = "";

            if (dt is null)
            {
                labelDatos.Text = "No hay datos";
            }
            else if (dt.Rows.Count == 0)
            {
                labelDatos.Text = "No hay datos";
            }
            else
            {
                DataRow row = dt.Rows[0];
                foreach (DataColumn column in dt.Columns)
                {
                    texto += column.ColumnName + ": " + row[column].ToString() + Environment.NewLine;
                }
            }
            labelDatos.Text = texto;
        }

        private void pictureBoxPhoto_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Title = "Elije una imagen";
                dlg.Filter = "Image Files (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png";
                dlg.Multiselect = false;
                if (dlg.ShowDialog() != DialogResult.OK)
                {
                    return;
                }

                string file = dlg.FileName;
                string ext = System.IO.Path.GetExtension(file)?.ToLowerInvariant() ?? string.Empty;
                if (ext != ".jpg" && ext != ".jpeg" && ext != ".png")
                {
                    MessageBox.Show("Solamente estan permitidas imagenes jpg y png.", "Invalid file type", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                try
                {
                    using (FileStream fs = new System.IO.FileStream(file, System.IO.FileMode.Open, System.IO.FileAccess.Read))
                    using (Image img = System.Drawing.Image.FromStream(fs))
                    {
                        // Create a copy so the stream can be closed safely
                        Bitmap bmp = new System.Drawing.Bitmap(img);
                        // Dispose previous image if any
                        Image prev = pictureBoxPhoto.Image;
                        pictureBoxPhoto.Image = bmp;
                        pictureBoxPhoto.SizeMode = PictureBoxSizeMode.Zoom;
                        prev?.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Fallo a la hora de la carga: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }

    }
}
